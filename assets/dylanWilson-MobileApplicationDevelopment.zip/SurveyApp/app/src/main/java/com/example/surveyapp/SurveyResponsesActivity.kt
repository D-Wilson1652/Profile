package com.example.surveyapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.DisplayListView
import com.example.surveyapp.model.mySurvey
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class SurveyResponsesActivity : AppCompatActivity(){
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.survey_responces)
        val myDataBase = mySurvey(this)
        var arrayAdapter: ArrayAdapter<*>
        var lists:Array<String> = arrayOf("Choose an Expired Survey")
        var SurvId:Array<Int> = arrayOf(0)

        var allpublishedSurveys = myDataBase.getAllPublishedSurvey()
        var allSurveys = myDataBase.getAllSurveys()
        var allStudresp = myDataBase.getAllStudentSurveyResponds()
        val currentdate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        for (i in allpublishedSurveys) {
            var sdformat = SimpleDateFormat("dd/MM/yyyy")
            var CurrentDate: Date = sdformat.parse(currentdate)
            var EndDate: Date = sdformat.parse(i.EndDate)
            if (CurrentDate.compareTo(EndDate)>0) {
                for(j in allSurveys){
                    if(j.Id==i.SurveyId){
                        lists+=j.Title
                        SurvId+=j.Id
                    }
                }}}
        var mListView = findViewById<ListView>(R.id.SurveyResponceslist)
        arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, lists)
        mListView.adapter = arrayAdapter
        mListView.setOnItemClickListener { parent, view, position, _ ->
            val selectedItem = parent.getItemAtPosition(position)
            var tempvar=0
            var PSurveyID=0
            for(j in lists) {
                if (j == selectedItem.toString()) {
                    PSurveyID = SurvId[tempvar].toInt()
                }
                tempvar += 1
            }
            if (PSurveyID!=0){
                val intent =
                    Intent(this, SurveyResponsesViewActivity::class.java).apply {
                        putExtra("PSurveyId", PSurveyID)
                    }
                startActivity(intent)
            }
            else{
                Toast.makeText(applicationContext,"please pick an expired survey! if none are available, change the dates on the existing surveys", Toast.LENGTH_LONG).show()
            }




            }
        }
    }