package com.example.surveyapp.model

data class Admin(val Id: Int, val LoginName: String, val PassWord: String) {
}