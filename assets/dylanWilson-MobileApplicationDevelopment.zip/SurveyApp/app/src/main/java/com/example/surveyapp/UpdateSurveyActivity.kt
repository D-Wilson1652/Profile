package com.example.surveyapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.mySurvey

class UpdateSurveyActivity : AppCompatActivity(){
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.update_survey)
        val arrayAdapter: ArrayAdapter<*>
        val mydatabase= mySurvey(this)
        val allpublishedSurveys=mydatabase.getAllPublishedSurvey()
        var tempArray:Array<String> = arrayOf("Which Survey do you want to update")
        val allSurveys=mydatabase.getAllSurveys()
        var mListView = findViewById<ListView>(R.id.UpdatePickSurvey)
        var idarray:Array<Int> = arrayOf()
        var pidarray:Array<Int> = arrayOf()

        for (i in allSurveys){
            var flag=false
            for (j in allpublishedSurveys){
                if (i.Id==j.SurveyId){
                    pidarray+=j.Id
                    flag=true
                }
            }
            if (flag){
                idarray+=i.Id
                tempArray+=i.Title
            }
        }
        arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, tempArray)
        mListView.adapter = arrayAdapter
        mListView.setOnItemClickListener { parent, view, position, _ ->
            val selectedItem = parent.getItemAtPosition(position)
            val index = tempArray.size
            for (i in 1..index) {
                if (selectedItem.toString() == tempArray[i - 1]) {
                    val intent = Intent(this, UpdateMenu::class.java).apply {
                        putExtra("SurveyID", idarray[i-2])
                        putExtra("PSurveyID", pidarray[i-2])

                    }
                    startActivity(intent)

                }
            }
        }
    }
}