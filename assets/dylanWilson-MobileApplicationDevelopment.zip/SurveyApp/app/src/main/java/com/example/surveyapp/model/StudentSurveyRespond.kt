package com.example.surveyapp.model

data class StudentSurveyRespond(val Id:  Int, val StudentId: Int, val PublishedSurveyId: Int, val QuestionId: Int, val AnswerId: Int) {
}