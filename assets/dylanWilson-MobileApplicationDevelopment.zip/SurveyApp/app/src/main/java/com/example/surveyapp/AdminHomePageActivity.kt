package com.example.surveyapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AdminHomePageActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.admin_home)
        val arrayAdapter:ArrayAdapter<*>
        val options= arrayOf("Admin Page","Create a New Survey","Upload a Survey","Update a Survey","Display Active Surveys","Survey Responses","Stats of each survey")
        var mListView = findViewById<ListView>(R.id.adminListView)
        arrayAdapter = ArrayAdapter(this,
            android.R.layout.simple_list_item_1, options)
        mListView.adapter = arrayAdapter
        mListView.setOnItemClickListener { parent, view, position, _ ->
            val selectedItem = parent.getItemAtPosition(position)
            if (selectedItem.toString()=="Create a New Survey"){
                val intent = Intent(this, CreateNewSurveyActivity::class.java).apply {
                    putExtra("Update",false)
                    putExtra("SurveyID",0)
                }
                startActivity(intent)}
            else if (selectedItem.toString()=="Upload a Survey"){
                val intent = Intent(this, UploadSurveyActivity::class.java)
                startActivity(intent)
            }
            else if (selectedItem.toString()=="Update a Survey"){
                val intent = Intent(this, UpdateSurveyActivity::class.java)
                startActivity(intent)
            }
            else if (selectedItem.toString()=="Display Active Surveys"){
                val intent = Intent(this, DisplayActiveSurveysActivity::class.java)
                startActivity(intent)
            }
            else if (selectedItem.toString()=="Survey Responses"){
                val intent = Intent(this, SurveyResponsesActivity::class.java)
                startActivity(intent)
            }
            else if (selectedItem.toString()=="Stats of each survey"){
                Toast.makeText(applicationContext,"Not Yet Implemented", Toast.LENGTH_SHORT).show()
            }
        }



    }
    fun logOut(view: View){
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
    }
}