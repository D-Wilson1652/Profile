package com.example.surveyapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.mySurvey

class UpdateMenu : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.update_menu)
        val arrayAdapter: ArrayAdapter<*>
        val mydatabase = mySurvey(this)
        var tempArray: Array<String> = arrayOf("What would you like to do", "Change the Dates of the Survey","Change the Question Title and/or Questions")
        var mListView = findViewById<ListView>(R.id.UpdateMenu)
        val surveyId=intent.getIntExtra("SurveyID",0)
        val psurveyId=intent.getIntExtra("PSurveyID",0)
        arrayAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, tempArray)
        mListView.adapter = arrayAdapter
        mListView.setOnItemClickListener { parent, view, position, _ ->
            val selectedItem = parent.getItemAtPosition(position)
            if (selectedItem.toString()=="Change the Dates of the Survey"){
                val intent = Intent(this, ChangeDates::class.java).apply{
                    putExtra("SurveyID",surveyId)
                    putExtra("Update",true)
                    putExtra("PSurveyID",psurveyId)
                }
                startActivity(intent)
            }
            else if (selectedItem.toString()=="Change the Question Title and/or Questions"){


                val intent = Intent(this, CreateNewSurveyActivity::class.java).apply{
                    putExtra("SurveyID",surveyId)
                    putExtra("Update",true)

                }
                startActivity(intent)
            }
        }

    }
}