package com.example.surveyapp.model

data class PublishedSurvey(val Id: Int, val SurveyId: Int, val StartDate: String, val EndDate: String) {
}