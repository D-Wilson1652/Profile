package com.example.surveyapp.model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.surveyapp.R

class ListviewClass (private val appContext: Context, private val moduleCodeList: Array<String>,
                                         private val moduleStartTimeList: Array<String>,private val moduleEndTimeList: Array<String>) : BaseAdapter() {

    private val inflater: LayoutInflater
            = appContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return moduleCodeList.size
    }

    override fun getItem(i: Int): Any? {
        return i
    }

    override fun getItemId(i: Int): Long {
        return i.toLong()
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {

        var view: View? = view
        view = inflater.inflate(R.layout.list_view, parent, false)

        val mCode = view.findViewById<TextView>(R.id.textViewMCode)
        val nStime = view.findViewById<TextView>(R.id.textViewMSTime)
        val nEtime = view.findViewById<TextView>(R.id.textViewMETime)

        mCode.text = moduleCodeList[position]
        nStime.text = moduleStartTimeList[position]
        nEtime.text = moduleEndTimeList[position]
        return view

    }

}
