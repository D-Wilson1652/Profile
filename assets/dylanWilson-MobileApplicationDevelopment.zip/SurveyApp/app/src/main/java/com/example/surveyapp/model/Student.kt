package com.example.surveyapp.model

data class Student(val Id: Int, val LoginName: String, val PassWord: String) {

}
