package com.example.surveyapp.model

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
private val DataBaseName = "SurveyDataBase.db"
private val ver : Int = 1
class mySurvey(context: Context) : SQLiteOpenHelper(context,DataBaseName,null ,ver){
    /*StudentSurveyRespond Table*/
    val StudentSurveyRespondTableName = "StudentSurveyRespond"
    val StudentSurveyRespondColumnId ="Id"
    val StudentSurveyRespondColumnStudentId = "StudentId"
    val StudentSurveyRespondColumnPublishedSurveyId = "PublishedSurveyId"
    val StudentSurveyRespondColumnQuestionId ="QuestionId"
    val StudentSurveyRespondColumnAnwserId = "AnwserId"
    /*PublishedSurvey Table*/
    val PublishedSurveyTableName = "PublishedSurvey"
    val PublishedSurveyColumnId="Id"
    val PublishedSurveyColumnSurveyId="SurveyId"
    val PublishedSurveyColumnStartDate="StartDate"
    val PublishedSurveyColumnEndDate="EndDate"
    /*Student Table*/
    val StudentTableName = "Student"
    val StudentColumnId ="Id"
    val StudentColumnLoginName="LoginName"
    val StudentColumnPassWord="PassWord"
    /*Admin Table*/
    val AdminTableName= "Admin"
    val AdminColumnId="Id"
    val AdminColumnLoginName="LoginName"
    val AdminColumnPassWord="PassWord"
    /*Answer Table*/
    val AnswerTableName="Answer"
    val AnswerColumnId="Id"
    val AnswerColumnAnswerText="AnswerText"
    /*Question Table*/
    val QuestionTableName="Question"
    val QuestionColumnId="Id"
    val QuestionColumnSurveyId="SurveyId"
    val QuestionColumnQuestionText="QuestionText"
    /*Survey Table*/
    val SurveyTableName="Survey"
    val SurveyColumnId="Id"
    val SurveyColumnTitle="Title"

    override fun onCreate(db: SQLiteDatabase?) {
        try{
            var sqlCreateStatement: String = "CREATE TABLE"  +
                    StudentSurveyRespondTableName + " ( " +
                    StudentSurveyRespondColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    StudentSurveyRespondColumnStudentId + " INTEGER  NOT NULL," +
                    StudentSurveyRespondColumnPublishedSurveyId + " INTEGER  NOT NULL," +
                    StudentSurveyRespondColumnQuestionId + " INTEGER  NOT NULL," +
                    StudentSurveyRespondColumnAnwserId+" INTEGER  NOT NULL, )"

            db?.execSQL(sqlCreateStatement)
            sqlCreateStatement= "CREATE TABLE"  +
                    PublishedSurveyTableName + " ( " +
                    PublishedSurveyColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    PublishedSurveyColumnSurveyId + " INTEGER  NOT NULL," +
                    PublishedSurveyColumnStartDate + " TEXT  NOT NULL," +
                    PublishedSurveyColumnEndDate+" TEXT  NOT NULL, )"

            db?.execSQL(sqlCreateStatement)
            sqlCreateStatement= "CREATE TABLE"  +
                    StudentTableName + " ( " +
                    StudentColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    StudentColumnLoginName + " TEXT  NOT NULL," +
                    StudentColumnPassWord+" TEXT  NOT NULL, )"

            db?.execSQL(sqlCreateStatement)
            sqlCreateStatement= "CREATE TABLE"  +
                    AdminTableName + " ( " +
                    AdminColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    AdminColumnLoginName + " TEXT  NOT NULL," +
                    AdminColumnPassWord+" TEXT  NOT NULL, )"

            db?.execSQL(sqlCreateStatement)
            sqlCreateStatement= "CREATE TABLE"  +
                    AnswerTableName + " ( " +
                    AnswerColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    AnswerColumnAnswerText+" TEXT  NOT NULL, )"

            db?.execSQL(sqlCreateStatement)
            sqlCreateStatement= "CREATE TABLE"  +
                    QuestionTableName + " ( " +
                    QuestionColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    QuestionColumnSurveyId + " TEXT  NOT NULL," +
                    QuestionColumnQuestionText+" TEXT  NOT NULL, )"

            db?.execSQL(sqlCreateStatement)
            sqlCreateStatement= "CREATE TABLE"  +
                    SurveyTableName + " ( " +
                    SurveyColumnId + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    SurveyColumnTitle+" INTEGER  NOT NULL, )"

            db?.execSQL(sqlCreateStatement)

        }
        catch(e : SQLException){}

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }


    fun getStudent(eID:Int): Student{
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $StudentTableName WHERE $StudentColumnId =$eID"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst()){
            // The ID is found
            db.close()
            return Student(cursor.getInt(0), cursor.getString(1),
                cursor.getString(2))
        }
        else {
            db.close()
                return Student(0, "Student not exist","Student Password not exist") //not found
        }
    }

    fun getAdmin(eID:Int): Admin{
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $AdminTableName WHERE $AdminColumnId =$eID"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst()){
            // The ID is found
            db.close()
            return Admin(cursor.getInt(0), cursor.getString(1),
                cursor.getString(2))
        }
        else {
            db.close()
            return Admin(0, "Admin not exist","Admin Password not exist") //not found
        }
    }

    fun getQuestion(eID: Int): Question{
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $QuestionTableName WHERE $QuestionColumnId =$eID"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst()){
            // The ID is found
            db.close()
            return Question(cursor.getInt(0), cursor.getString(1),
                cursor.getString(2))
        }
        else {
            db.close()
            return Question(0, "Student not exist","Question not exist") //not found
        }
    }

    fun getAnswer(eID:Int): Answer{
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $AnswerTableName WHERE $AnswerColumnId =$eID"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst()){
            // The ID is found
            db.close()
            return Answer(cursor.getInt(0), cursor.getString(1))
        }
        else {
            db.close()
            return Answer(0, "Answer not exist") //not found
        }
    }

    fun getPublishedSurvey(eID:Int): PublishedSurvey{
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $PublishedSurveyTableName WHERE $PublishedSurveyColumnId =$eID"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst()){
            // The ID is found
            db.close()
            return PublishedSurvey(cursor.getInt(0), cursor.getInt(1),
                cursor.getString(2),cursor.getString(3),)
        }
        else {
            db.close()
            return PublishedSurvey(0, 0,"Start Date not exist", "End Date not exist") //not found
        }
    }

    fun getStudentSurveyRespond(eID:Int): StudentSurveyRespond{
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $StudentSurveyRespondTableName WHERE $StudentSurveyRespondColumnId =$eID"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst()){
            // The ID is found
            db.close()
            return StudentSurveyRespond(cursor.getInt(0), cursor.getInt(1),
                cursor.getInt(2),cursor.getInt(3),cursor.getInt(4))
        }
        else {
            db.close()
            return StudentSurveyRespond(0, 0,0,0,0) //not found
        }

    }

    fun getSurvey(eID:Int): Question{
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $SurveyTableName WHERE $SurveyColumnId =$eID"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst()){
            // The ID is found
            db.close()
            return Question(cursor.getInt(0), cursor.getString(1),
                cursor.getString(2))
        }
        else {
            db.close()
            return Question(0, "Student not exist","Question not exist") //not found
        }
    }

    fun getAllStudents() : ArrayList<Student> {
        val StudentList = ArrayList<Student>()
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $StudentTableName"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst())
            do {
                val Id: Int = cursor.getInt(0)
                val LoginName: String = cursor.getString(1)
                val PassWord: String = cursor.getString(2)
                val emp = Student(Id,LoginName,PassWord)
                StudentList.add(emp)
            }while(cursor.moveToNext())
        cursor.close()
        db.close()
        return StudentList
    }

    fun getAllAdmins() : ArrayList<Admin> {
        val AdminList = ArrayList<Admin>()
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $AdminTableName"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst())
            do {
                val Id: Int = cursor.getInt(0)
                val LoginName: String = cursor.getString(1)
                val PassWord: String = cursor.getString(2)
                val emp = Admin(Id,LoginName,PassWord)
                AdminList.add(emp)
            }while(cursor.moveToNext())
        cursor.close()
        db.close()
        return AdminList
    }

    fun getAllQuestions() : ArrayList<Question> {
        val QuestionList = ArrayList<Question>()
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $QuestionTableName"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst())
            do {
                val id: Int = cursor.getInt(0)
                val SurveyId: String = cursor.getString(1)
                val QuestionText: String = cursor.getString(2)
                val emp = Question(id,SurveyId,QuestionText)
                QuestionList.add(emp)
            }while(cursor.moveToNext())
        cursor.close()
        db.close()
        return QuestionList
    }

    fun getAllAnswers() : ArrayList<Answer> {
        val AnswerList = ArrayList<Answer>()
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $AnswerTableName"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst())
            do {
                val id: Int = cursor.getInt(0)
                val AnswerText: String = cursor.getString(1)
                val emp = Answer(id,AnswerText)
                AnswerList.add(emp)
            }while(cursor.moveToNext())
        cursor.close()
        db.close()
        return AnswerList
    }

    fun getAllSurveys() : ArrayList<Survey> {
        val SurveyList = ArrayList<Survey>()
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $SurveyTableName"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst())
            do {
                val id: Int = cursor.getInt(0)
                val Title: String = cursor.getString(1)
                val emp = Survey(id,Title)
                SurveyList.add(emp)
            }while(cursor.moveToNext())
        cursor.close()
        db.close()
        return SurveyList
    }

    fun getAllStudentSurveyResponds() : ArrayList<StudentSurveyRespond> {
        val StudentSurveyRespondList = ArrayList<StudentSurveyRespond>()
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $StudentSurveyRespondTableName"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst())
            do {
                val id: Int = cursor.getInt(0)
                val StudentId: Int = cursor.getInt(1)
                val PublishedSurveyId: Int = cursor.getInt(2)
                val QuestionId: Int = cursor.getInt(3)
                val AnswerId: Int = cursor.getInt(4)
                val emp = StudentSurveyRespond(id,StudentId,PublishedSurveyId,QuestionId,AnswerId)
                StudentSurveyRespondList.add(emp)
            }while(cursor.moveToNext())
        cursor.close()
        db.close()
        return StudentSurveyRespondList
    }

    fun getAllPublishedSurvey() : ArrayList<PublishedSurvey> {
        val PublishedSurveyList = ArrayList<PublishedSurvey>()
        val db: SQLiteDatabase = this.readableDatabase
        val sqlStatement = "SELECT * FROM $PublishedSurveyTableName"
        val cursor: Cursor = db.rawQuery(sqlStatement,null)
        if(cursor.moveToFirst())
            do {
                val id: Int = cursor.getInt(0)
                val SurveyId: Int = cursor.getInt(1)
                val StartDate: String = cursor.getString(2)
                val EndDate: String = cursor.getString(3)
                val emp = PublishedSurvey(id,SurveyId,StartDate,EndDate)
                PublishedSurveyList.add(emp)
            }while(cursor.moveToNext())
        cursor.close()
        db.close()
        return PublishedSurveyList
    }

    fun addStudent(student: Student) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(StudentColumnLoginName, student.LoginName)
        cv.put(StudentColumnPassWord,student.PassWord)
        val success = db.insert(StudentTableName, null, cv)
        db.close()
        return success != -1L
    }

    fun addAdmin(admin: Admin) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(AdminColumnLoginName, admin.LoginName)
        cv.put(AdminColumnPassWord,admin.PassWord)
        val success = db.insert(AdminTableName, null, cv)
        db.close()
        return success != -1L
    }

    fun addQuestion(question: Question) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(QuestionColumnSurveyId, question.SurveyId)
        cv.put(QuestionColumnQuestionText,question.QuestionText)
        val success = db.insert(QuestionTableName, null, cv)
        db.close()
        return success != -1L
    }

    fun addAnswer(answer: Answer) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(AnswerColumnAnswerText, answer.AnswerText)
        val success = db.insert(AnswerTableName, null, cv)
        db.close()
        return success != -1L
    }

    fun addSurvey(survey: Survey) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(SurveyColumnTitle, survey.Title)
        val success = db.insert(SurveyTableName, null, cv)
        db.close()
        return success != -1L
    }

    fun addPublishedSurvey(publishedSurvey: PublishedSurvey) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(PublishedSurveyColumnSurveyId, publishedSurvey.SurveyId)
        cv.put(PublishedSurveyColumnStartDate ,publishedSurvey.StartDate)
        cv.put(PublishedSurveyColumnEndDate ,publishedSurvey.EndDate)
        val success = db.insert(PublishedSurveyTableName, null, cv)
        db.close()
        return success != -1L
    }

    fun addStudentSurveyRespond(studentSurveyRespond: StudentSurveyRespond) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(StudentSurveyRespondColumnStudentId, studentSurveyRespond.StudentId)
        cv.put(StudentSurveyRespondColumnPublishedSurveyId,studentSurveyRespond.PublishedSurveyId)
        cv.put(StudentSurveyRespondColumnQuestionId,studentSurveyRespond.QuestionId)
        cv.put(StudentSurveyRespondColumnAnwserId,studentSurveyRespond.AnswerId)
        val success = db.insert(StudentSurveyRespondTableName, null, cv)
        db.close()
        return success != -1L
    }

    fun deleteAdmin(admin: Admin) : Boolean{
        // delete employee if exist in the database
        // writableDatabase for delete actions
        val db: SQLiteDatabase = this.writableDatabase
        val result = db.delete(AdminTableName, "$AdminColumnId =${admin.Id}", null) == 1
        db.close()
        return result
    }

    fun deleteAnswer(answer: Answer) : Boolean {
        // delete employee if exist in the database
        // writableDatabase for delete actions
        val db: SQLiteDatabase = this.writableDatabase
        val result = db.delete(AnswerTableName, "$AnswerColumnId =${answer.Id}", null) == 1
        db.close()
        return result
    }

    fun deletePublishedSurvey(publishedSurvey: PublishedSurvey) : Boolean {
        // delete employee if exist in the database
        // writableDatabase for delete actions
        val db: SQLiteDatabase = this.writableDatabase
        val result = db.delete(PublishedSurveyTableName, "$PublishedSurveyColumnId =${publishedSurvey.Id}", null) == 1
        db.close()
        return result
    }

    fun deleteQuestion(question: Question) : Boolean {
        // delete employee if exist in the database
        // writableDatabase for delete actions
        val db: SQLiteDatabase = this.writableDatabase
        val result = db.delete(QuestionTableName, "$QuestionColumnId =${question.Id}", null) == 1
        db.close()
        return result
    }

    fun deleteStudent(student: Student) : Boolean {
        // delete employee if exist in the database
        // writableDatabase for delete actions
        val db: SQLiteDatabase = this.writableDatabase
        val result = db.delete(StudentTableName, "$StudentColumnId =${student.Id}", null) == 1
        db.close()
        return result
    }

    fun deleteStudentSurveyRespond(studentSurveyRespond: StudentSurveyRespond) : Boolean {
        // delete employee if exist in the database
        // writableDatabase for delete actions
        val db: SQLiteDatabase = this.writableDatabase
        val result = db.delete(StudentSurveyRespondTableName, "$StudentSurveyRespondColumnId =${studentSurveyRespond.Id}", null) == 1
        db.close()
        return result
    }

    fun deleteSurvey(survey: Survey) : Boolean {
        // delete employee if exist in the database
        // writableDatabase for delete actions
        val db: SQLiteDatabase = this.writableDatabase
        val result = db.delete(SurveyTableName, "$SurveyColumnId =${survey.Id}", null) == 1
        db.close()
        return result
    }

    fun updateAdmin(admin: Admin) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(AdminColumnLoginName, admin.LoginName)
        cv.put(AdminColumnPassWord,admin.PassWord)
        val result = db.update(AdminTableName,cv,"$AdminColumnId =${admin.Id}", null) == 1
        db.close()
        return result
    }

    fun updateAnswer(answer: Answer) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(AnswerColumnAnswerText, answer.AnswerText)
        val result = db.update(AnswerTableName,cv,"$AnswerColumnId =${answer.Id}", null) == 1
        db.close()
        return result
    }

    fun updatePublishedSurvey(publishedSurvey: PublishedSurvey) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(PublishedSurveyColumnSurveyId, publishedSurvey.SurveyId)
        cv.put(PublishedSurveyColumnStartDate,publishedSurvey.StartDate)
        cv.put(PublishedSurveyColumnEndDate,publishedSurvey.EndDate)
        val result = db.update(PublishedSurveyTableName,cv,"$PublishedSurveyColumnId =${publishedSurvey.Id}", null) == 1
        db.close()
        return result
    }

    fun updateQuestion(question: Question) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(QuestionColumnSurveyId, question.SurveyId)
        cv.put(QuestionColumnQuestionText,question.QuestionText)
        val result = db.update(QuestionTableName,cv,"$QuestionColumnId =${question.Id}", null) == 1
        db.close()
        return result
    }

    fun updateStudent(student: Student) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(StudentColumnLoginName, student.LoginName)
        cv.put(StudentColumnPassWord,student.PassWord)
        val result = db.update(StudentTableName,cv,"$StudentColumnId =${student.Id}", null) == 1
        db.close()
        return result
    }

    fun updateStudentSurveyRespond(studentSurveyRespond: StudentSurveyRespond) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(StudentSurveyRespondColumnStudentId, studentSurveyRespond.StudentId)
        cv.put(StudentSurveyRespondColumnPublishedSurveyId,studentSurveyRespond.PublishedSurveyId)
        cv.put(StudentSurveyRespondColumnQuestionId, studentSurveyRespond.QuestionId)
        cv.put(StudentSurveyRespondColumnAnwserId,studentSurveyRespond.AnswerId)
        val result = db.update(StudentSurveyRespondTableName,cv,"$StudentSurveyRespondColumnId =${studentSurveyRespond.Id}", null) == 1
        db.close()
        return result
    }

    fun updateSurvey(survey: Survey) : Boolean {
        // writableDatabase for insert actions
        val db: SQLiteDatabase = this.writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put(SurveyColumnTitle, survey.Title)
        val result = db.update(SurveyTableName,cv,"$SurveyColumnId =${survey.Id}", null) == 1
        db.close()
        return result
    }

}