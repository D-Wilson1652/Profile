package com.example.surveyapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.get
import androidx.core.view.isEmpty
import com.example.surveyapp.model.Question
import com.example.surveyapp.model.Survey
import com.example.surveyapp.model.mySurvey

class CreateNewSurveyActivity : AppCompatActivity(){
    @SuppressLint("WrongViewCast", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.create_new_survey)
        val update= intent.getBooleanExtra("Update",false)
        val surveyid = intent.getIntExtra("SurveyID",0)
        if (update){
            var createqtitle = findViewById<EditText>(R.id.CreateQuestionTitleInput)
            var createq1 = findViewById<EditText>(R.id.CreateQuestionInput1)
            var createq2 = findViewById<EditText>(R.id.CreateQuestionInput2)
            var createq3 = findViewById<EditText>(R.id.CreateQuestionInput3)
            var createq4 = findViewById<EditText>(R.id.CreateQuestionInput4)
            var createq5 = findViewById<EditText>(R.id.CreateQuestionInput5)
            var createq6 = findViewById<EditText>(R.id.CreateQuestionInput6)
            var createq7 = findViewById<EditText>(R.id.CreateQuestionInput7)
            var createq8 = findViewById<EditText>(R.id.CreateQuestionInput8)
            var createq9 = findViewById<EditText>(R.id.CreateQuestionInput9)
            var createq10 = findViewById<EditText>(R.id.CreateQuestionInput10)
            val mydatabase=mySurvey(this)
            val surveyID = mydatabase.getAllSurveys()
            val qID = mydatabase.getAllQuestions()
            for(x in surveyID){
                if(x.Id==surveyid){
                    createqtitle.setText(x.Title)
                }
            }
            for(y in qID){
                if(y.SurveyId==surveyid.toString()){
                    if(y.Id.mod(10)==1){createq1.setText(y.QuestionText)}
                    else if(y.Id.mod(10)==2){ createq2.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==3){ createq3.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==4){ createq4.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==5){ createq5.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==6){ createq6.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==7){ createq7.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==8){ createq8.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==9){ createq9.setText(y.QuestionText) }
                    else if(y.Id.mod(10)==0){ createq10.setText(y.QuestionText) }
                }
            }
        }

    }
    fun create(view: View){
        val update=intent.getBooleanExtra("Update",false)
        var createqtitle = findViewById<EditText>(R.id.CreateQuestionTitleInput).text.toString()
        var createq1 = findViewById<EditText>(R.id.CreateQuestionInput1).text.toString()
        var createq2 = findViewById<EditText>(R.id.CreateQuestionInput2).text.toString()
        var createq3 = findViewById<EditText>(R.id.CreateQuestionInput3).text.toString()
        var createq4 = findViewById<EditText>(R.id.CreateQuestionInput4).text.toString()
        var createq5 = findViewById<EditText>(R.id.CreateQuestionInput5).text.toString()
        var createq6 = findViewById<EditText>(R.id.CreateQuestionInput6).text.toString()
        var createq7 = findViewById<EditText>(R.id.CreateQuestionInput7).text.toString()
        var createq8 = findViewById<EditText>(R.id.CreateQuestionInput8).text.toString()
        var createq9 = findViewById<EditText>(R.id.CreateQuestionInput9).text.toString()
        var createq10 = findViewById<EditText>(R.id.CreateQuestionInput10).text.toString()
        if (createqtitle.isEmpty() || createq1.isEmpty()|| createq2.isEmpty()|| createq3.isEmpty()||
            createq4.isEmpty()|| createq5.isEmpty()|| createq6.isEmpty()|| createq7.isEmpty()||
            createq8.isEmpty()|| createq9.isEmpty()|| createq10.isEmpty()) {
            Toast.makeText(this, "Please Complete all Questions and the Title" , Toast.LENGTH_LONG).show()
        }
        else{
            val mydatabase=mySurvey(this)
            if (!update){
                val x = Survey(-1,createqtitle)
                mydatabase.addSurvey(x)
                val y=mydatabase.getAllSurveys().size
                var newquestion1= Question(-1,(y).toString(),createq1)
                var newquestion2= Question(-1,(y).toString(),createq2)
                var newquestion3= Question(-1,(y).toString(),createq3)
                var newquestion4= Question(-1,(y).toString(),createq4)
                var newquestion5= Question(-1,(y).toString(),createq5)
                var newquestion6= Question(-1,(y).toString(),createq6)
                var newquestion7= Question(-1,(y).toString(),createq7)
                var newquestion8= Question(-1,(y).toString(),createq8)
                var newquestion9= Question(-1,(y).toString(),createq9)
                var newquestion10= Question(-1,(y).toString(),createq10)
                mydatabase.addQuestion(newquestion1)
                mydatabase.addQuestion(newquestion2)
                mydatabase.addQuestion(newquestion3)
                mydatabase.addQuestion(newquestion4)
                mydatabase.addQuestion(newquestion5)
                mydatabase.addQuestion(newquestion6)
                mydatabase.addQuestion(newquestion7)
                mydatabase.addQuestion(newquestion8)
                mydatabase.addQuestion(newquestion9)
                mydatabase.addQuestion(newquestion10)
                Toast.makeText(this, "Survey Created Please Upload the survey to allow access to the Students" , Toast.LENGTH_LONG).show()
                val intent = Intent(this, AdminHomePageActivity::class.java)
                startActivity(intent)

            }
            else{
                var surveyid = intent.getIntExtra("SurveyId",0)
                if (surveyid>=4) {
                    var question1ID = (surveyid * 10) + 1
                    var question2ID = (surveyid * 10) + 2
                    var question3ID = (surveyid * 10) + 3
                    var question4ID = (surveyid * 10) + 4
                    var question5ID = (surveyid * 10) + 5
                    var question6ID = (surveyid * 10) + 6
                    var question7ID = (surveyid * 10) + 7
                    var question8ID = (surveyid * 10) + 8
                    var question9ID = (surveyid * 10) + 9
                    var question10ID = (surveyid * 10) + 10
                    var newquestion1 = Question(question1ID, surveyid.toString(), createq1)
                    var newquestion2 = Question(question2ID, surveyid.toString(), createq2)
                    var newquestion3 = Question(question3ID, surveyid.toString(), createq3)
                    var newquestion4 = Question(question4ID, surveyid.toString(), createq4)
                    var newquestion5 = Question(question5ID, surveyid.toString(), createq5)
                    var newquestion6 = Question(question6ID, surveyid.toString(), createq6)
                    var newquestion7 = Question(question7ID, surveyid.toString(), createq7)
                    var newquestion8 = Question(question8ID, surveyid.toString(), createq8)
                    var newquestion9 = Question(question9ID, surveyid.toString(), createq9)
                    var newquestion10 = Question(question10ID, surveyid.toString(), createq10)
                    mydatabase.updateQuestion(newquestion1)
                    mydatabase.updateQuestion(newquestion2)
                    mydatabase.updateQuestion(newquestion3)
                    mydatabase.updateQuestion(newquestion4)
                    mydatabase.updateQuestion(newquestion5)
                    mydatabase.updateQuestion(newquestion6)
                    mydatabase.updateQuestion(newquestion7)
                    mydatabase.updateQuestion(newquestion8)
                    mydatabase.updateQuestion(newquestion9)
                    mydatabase.updateQuestion(newquestion10)
                }
                else{
                    var newquestion1 = Question(1, surveyid.toString(), createq1)
                    var newquestion2 = Question(2, surveyid.toString(), createq2)
                    var newquestion3 = Question(3, surveyid.toString(), createq3)
                    var newquestion4 = Question(4, surveyid.toString(), createq4)
                    var newquestion5 = Question(5, surveyid.toString(), createq5)
                    var newquestion6 = Question(6, surveyid.toString(), createq6)
                    var newquestion7 = Question(7, surveyid.toString(), createq7)
                    var newquestion8 = Question(8, surveyid.toString(), createq8)
                    var newquestion9 = Question(9, surveyid.toString(), createq9)
                    var newquestion10 = Question(10, surveyid.toString(), createq10)
                    mydatabase.updateQuestion(newquestion1)
                    mydatabase.updateQuestion(newquestion2)
                    mydatabase.updateQuestion(newquestion3)
                    mydatabase.updateQuestion(newquestion4)
                    mydatabase.updateQuestion(newquestion5)
                    mydatabase.updateQuestion(newquestion6)
                    mydatabase.updateQuestion(newquestion7)
                    mydatabase.updateQuestion(newquestion8)
                    mydatabase.updateQuestion(newquestion9)
                    mydatabase.updateQuestion(newquestion10)
                    Toast.makeText(this, "The Survey Was Updated to the new dates" , Toast.LENGTH_LONG).show()
                    val intent = Intent(this, AdminHomePageActivity::class.java)
                    startActivity(intent)
                }

            }
        }

    }
}