package com.example.surveyapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.Student
import com.example.surveyapp.model.mySurvey

class RegisterActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_page)

    }
    fun register(view: View){
        var flag = true
        val message = findViewById<TextView>(R.id.registerErrorText)
        val usernameCreateInput = findViewById<EditText>(R.id.usernameCreate).text.toString()
        val PasswordCreateInput = findViewById<EditText>(R.id.passwordCreate).text.toString()
        val ConfirmPasswordCreateInput = findViewById<EditText>(R.id.confirmPasswordCreate).text.toString()
        val myDataBase = mySurvey(this)
        if (usernameCreateInput.isEmpty() || PasswordCreateInput.isEmpty() || ConfirmPasswordCreateInput.isEmpty()){
            Toast.makeText(this, "Please complete all of the fields ", Toast.LENGTH_LONG).show()
        }
        else {

            val allStudents = myDataBase.getAllStudents()
            val allAdmins = myDataBase.getAllAdmins()
            for(i in allAdmins) {
                if (usernameCreateInput== i.LoginName){
                    message.text="Username already in use"
                    flag=false
                }
            }
            for(i in allStudents){
                if (usernameCreateInput== i.LoginName){
                    message.text="Username already in use"
                    flag=false
                }
            }
        }
        if (flag){
            if (PasswordCreateInput!=ConfirmPasswordCreateInput){
                message.text="Passwords do not match"
            }
            else{
                var newStudent= Student(-1,usernameCreateInput,PasswordCreateInput)
                myDataBase.addStudent(newStudent)
                Toast.makeText(applicationContext,"Your account was successfully created", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
        }
    }
}