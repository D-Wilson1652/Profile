package com.example.surveyapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.PublishedSurvey
import com.example.surveyapp.model.mySurvey

class ChangeDates : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.change_dates)
        var updates=intent.getBooleanExtra("Update",false)
        var textt = findViewById<TextView>(R.id.TitleTextView)
        if (updates){

            textt.setText("Change The Dates For Your Survey")
        }
        if (!updates){
            textt.setText("Create The Dates For Your Survey")
        }

    }
    fun changedates(view: View){
        var newStartDate = findViewById<EditText>(R.id.NewStartDate).text.toString()
        var newEndDate = findViewById<EditText>(R.id.NewEndDate).text.toString()
        var survID = intent.getIntExtra("SurveyID", 0)
        var psurvID = intent.getIntExtra("PSurveyID", 0)

        var updates = intent.getBooleanExtra("Update",false)
        var changebutton=findViewById<Button>(R.id.changeDatesButton)


        if (newStartDate.get(2)!='/' ||newStartDate.get(5)!='/' ||newStartDate.length!=10){
            Toast.makeText(applicationContext,"Input a valid date - format dd/mm/yyyy", Toast.LENGTH_SHORT).show()
            }


        else {
            val mydatabase = mySurvey(this)
            if (!updates) {
                val newpub = PublishedSurvey(-1, survID, newStartDate, newEndDate)
                mydatabase.addPublishedSurvey(newpub)
                Toast.makeText(applicationContext, "Survey Uploaded", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, AdminHomePageActivity::class.java)
                startActivity(intent)
            }
            else{
                val newpub = PublishedSurvey(psurvID, survID, newStartDate, newEndDate)
                mydatabase.updatePublishedSurvey(newpub)
                Toast.makeText(applicationContext, "Survey Updated", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, AdminHomePageActivity::class.java)
                startActivity(intent)

            }
        }
    }
}
