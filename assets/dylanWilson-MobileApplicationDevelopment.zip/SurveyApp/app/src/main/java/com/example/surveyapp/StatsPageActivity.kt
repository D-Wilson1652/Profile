package com.example.surveyapp

class StatsPageActivity {
}