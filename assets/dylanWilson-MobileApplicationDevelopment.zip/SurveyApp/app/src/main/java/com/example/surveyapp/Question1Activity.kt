package com.example.surveyapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.view.View
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.StudentSurveyRespond
import com.example.surveyapp.model.mySurvey

class Question1Activity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    var questionID: ArrayList<Int> = arrayListOf()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.student_question_1)
        var pageNum: Int = 1
        val StronglyAgree = findViewById<RadioButton>(R.id.q1radioButton)
        val Agree = findViewById<RadioButton>(R.id.q1radioButton2)
        val NeitherAgreeNorDisagree = findViewById<RadioButton>(R.id.q1radioButton3)
        val Disagree = findViewById<RadioButton>(R.id.q1radioButton4)
        val StronglyDisagree = findViewById<RadioButton>(R.id.q1radioButton5)
        val myDataBase = mySurvey(this)
        var Nextbutton = findViewById<Button>(R.id.NextButton)
        var title = findViewById<TextView>(R.id.question1Title)
        var prevbutton = findViewById<Button>(R.id.PreviousButton)
        var finishButton = findViewById<Button>(R.id.FinishButton)
        val allAnswers = myDataBase.getAllAnswers()
        val radio_group=findViewById<RadioGroup>(R.id.q1RadioGroup)
        val allQuestions = myDataBase.getAllQuestions()
        val questionText = findViewById<TextView>(R.id.Question1Text)
        var studID = intent.getIntExtra("StudentID", 0)
        val passedSurveyid= intent.getIntExtra(EXTRA_MESSAGE, 0)
        val passedPublishedSurveyid= intent.getIntExtra("publishedID",0)

        StronglyAgree.text = myDataBase.getAnswer(1).AnswerText
        Agree.text = myDataBase.getAnswer(2).AnswerText
        NeitherAgreeNorDisagree.text = myDataBase.getAnswer(3).AnswerText
        Disagree.text = myDataBase.getAnswer(4).AnswerText
        StronglyDisagree.text = myDataBase.getAnswer(5).AnswerText

        for (i in allQuestions) {
            if (i.SurveyId == passedSurveyid.toString()) {
                if (i.Id.mod(10) == pageNum){
                    title.text = "Question "+pageNum.toString()
                    questionText.text = i.QuestionText
                    questionID+=i.Id

                }
            }
        }
        if (pageNum==1){
            prevbutton.visibility= INVISIBLE
            finishButton.visibility= INVISIBLE

        }
        else if(pageNum==10){
            Nextbutton.visibility= INVISIBLE
        }

        var lists: ArrayList<Int> = arrayListOf()
        Nextbutton.setOnClickListener{
            var id: Int = radio_group.checkedRadioButtonId
            if (id!=-1) {
                val radio: RadioButton = findViewById(id)
                radio.isChecked=false
                for (i in allAnswers) {
                    if (radio.text == i.AnswerText) {
                        lists+=i.Id
                        pageNum+=1
                        if (pageNum ==10){
                            pageNum=0
                        }
                        refreshPage(pageNum,true)
                    }

                }

            }

            else{Toast.makeText(applicationContext,"Please Select an Answer", Toast.LENGTH_SHORT).show()
            }

            radio_group.clearCheck()
        }


        prevbutton.setOnClickListener {
            var id: Int = radio_group.checkedRadioButtonId
            if (id != -1) {
                val radio: RadioButton = findViewById(id)
                radio.isChecked = false
                radio_group.clearCheck()

            }
            if (lists.last()==1){StronglyAgree.isChecked=true}
            else if (lists.last()==2){Agree.isChecked=true}
            else if (lists.last()==3){NeitherAgreeNorDisagree.isChecked=true}
            else if (lists.last()==4){Disagree.isChecked=true}
            else if (lists.last()==5){StronglyDisagree.isChecked=true}
            lists.removeAt(lists.size - 1)
            questionID.removeAt(questionID.size - 1)
            pageNum -= 1
            refreshPage(pageNum,false)




        }




        finishButton.setOnClickListener{
            var id: Int = radio_group.checkedRadioButtonId
            if (id!=-1) {
                val radio: RadioButton = findViewById(id)
                radio.isChecked=false
                for (i in allAnswers) {
                    if (radio.text == i.AnswerText) {
                        lists+=i.Id
                        pageNum+=1
                        for (a in allQuestions){
                            if (a.Id.mod(10) == 0 && a.SurveyId == passedSurveyid.toString()){
                                questionID+=a.Id
                            }
                        }

                    }
                }
                var newid:Int=myDataBase.getAllStudentSurveyResponds().size
                newid+=1
                for (j in 0..9 ){
                    var x=StudentSurveyRespond((newid+j),studID,passedPublishedSurveyid,questionID[j],lists[j])
                    myDataBase.addStudentSurveyRespond(x)
                }

                Toast.makeText(applicationContext,"Your Responces has been added to the database. Thank you for completing the quiz", Toast.LENGTH_LONG).show()

                val intent = Intent(this, StudentHomePageActivity::class.java).apply {
                    putExtra("StudentID", studID)}
                startActivity(intent)
            }

            else{
                Toast.makeText(applicationContext,"Please Select an Answer", Toast.LENGTH_SHORT).show()
            }
        }

    }
    fun refreshPage(pageNum:Int,flag:Boolean ){

        val myDataBase = mySurvey(this)
        var Nextbutton = findViewById<Button>(R.id.NextButton)
        var title = findViewById<TextView>(R.id.question1Title)
        var prevbutton = findViewById<Button>(R.id.PreviousButton)
        var finishButton = findViewById<Button>(R.id.FinishButton)
        val allQuestions = myDataBase.getAllQuestions()
        val questionText = findViewById<TextView>(R.id.Question1Text)
        val passedSurveyid = intent.getIntExtra(EXTRA_MESSAGE, 0)

        for (i in allQuestions) {
            if (i.SurveyId == passedSurveyid.toString()) {
                if (i.Id.mod(10) == pageNum){
                    title.text = "Question "+pageNum.toString()
                    if (pageNum==0 ){
                        title.text = "Question 10"
                    }
                    questionText.text = i.QuestionText
                    if (flag){
                        questionID+=i.Id
                    }
                }
            }
        }
        if (pageNum==1){
            prevbutton.visibility= INVISIBLE
            finishButton.visibility= INVISIBLE
            Nextbutton.visibility= VISIBLE
        }
        else if(pageNum==0){
            prevbutton.visibility= VISIBLE
            finishButton.visibility= VISIBLE
            Nextbutton.visibility= INVISIBLE
        }
        else{
            prevbutton.visibility= VISIBLE
            finishButton.visibility= INVISIBLE
            Nextbutton.visibility= VISIBLE
        }

    }


    }

