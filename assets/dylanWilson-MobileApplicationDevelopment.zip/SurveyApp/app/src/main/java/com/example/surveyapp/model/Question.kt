package com.example.surveyapp.model

data class Question(val Id: Int, val SurveyId:  String, val QuestionText: String) {

}