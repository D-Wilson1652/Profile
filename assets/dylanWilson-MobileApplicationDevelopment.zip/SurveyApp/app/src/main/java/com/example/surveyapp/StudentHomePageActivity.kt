package com.example.surveyapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.view.View
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.get
import com.example.surveyapp.model.ListviewClass
import com.example.surveyapp.model.mySurvey
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.collections.ArrayList

class StudentHomePageActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.student_home)
        val myDataBase = mySurvey(this)

        var moduleList: Array<String> = arrayOf("Module Name")
        var moduleStartTimeList: Array<String> = arrayOf("Start Date")
        var moduleEndTimeList: Array<String> = arrayOf("End Date")
        val allpublishedSurveys = myDataBase.getAllPublishedSurvey()
        val allSurveys = myDataBase.getAllSurveys()
        val currentdate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        var id:Array<Int> = arrayOf()
        var pid:Array<Int> = arrayOf()
        val AllStudentSurveyResponds=myDataBase.getAllStudentSurveyResponds()
        var studID=intent.getIntExtra("StudentID",0)
        for (i in allpublishedSurveys) {
            var pass = false
            var sdformat = SimpleDateFormat("dd/MM/yyyy")
            var CurrentDate: Date = sdformat.parse(currentdate)
            var StartDate: Date = sdformat.parse(i.StartDate)
            var EndDate: Date = sdformat.parse(i.EndDate)
            if (CurrentDate.compareTo(StartDate)>0 && CurrentDate.compareTo(EndDate)<0) {
                for (j in AllStudentSurveyResponds){
                    if (i.Id==j.PublishedSurveyId && j.StudentId==studID){
                        pass=true
                    }
                }
                if (!pass){
                    moduleStartTimeList += i.StartDate
                    moduleEndTimeList += i.EndDate
                    id += i.SurveyId
                    pid+=i.Id
                    for(f in allSurveys){
                        if (i.SurveyId==f.Id){
                            moduleList += f.Title
                        }
                    }
                }
            }
        }



        var simpleList: ListView = findViewById<ListView>(R.id.myListView)
        val customAdapter = ListviewClass(applicationContext, moduleList, moduleStartTimeList, moduleEndTimeList)
        simpleList!!.adapter = customAdapter

        simpleList.setOnItemClickListener { parent, view, position, _ ->
            val selectedItem = parent.getItemAtPosition(position)
            if (selectedItem.toString()!="0"){
                var target1:Int = id[selectedItem as Int-1]
                var target2:Int = pid[selectedItem as Int-1]
                //Toast.makeText(applicationContext,target1.toString(), Toast.LENGTH_SHORT).show()
                //Toast.makeText(applicationContext,target2.toString(), Toast.LENGTH_SHORT).show()
                val intent = Intent(this, Question1Activity::class.java).apply {
                    putExtra(EXTRA_MESSAGE, target1)
                    putExtra("publishedID", target2)
                    putExtra("StudentID", studID)}
                startActivity(intent)



            }

        }


    }
    fun LogOut(view: View){
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
    }
}
