package com.example.surveyapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.Admin
import com.example.surveyapp.model.mySurvey

class LoginActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_page)

    }
    fun CheckLogin(view: View) {
        var studentLogin=false
        var adminLogin=false
        val message = findViewById<TextView>(R.id.errorText)
        var studId:Int=0
        val usernameInput = findViewById<EditText>(R.id.usernameInput).text.toString()
        val PasswordInput = findViewById<EditText>(R.id.passwordInput).text.toString()
        if (usernameInput.isEmpty() || PasswordInput.isEmpty()) {
            Toast.makeText(this, "Incorrect Username or Password", Toast.LENGTH_LONG).show()
        }
        else {
            val myDataBase = mySurvey(this)
            val allStudents = myDataBase.getAllStudents()
            val allAdmins = myDataBase.getAllAdmins()
            for (i in allStudents) {
                if (i.LoginName == usernameInput && i.PassWord == PasswordInput) {
                    message.text = "Student successful login"
                    studId=i.Id
                    studentLogin=true
                }
            }
            for (i in allAdmins) {
                if (i.LoginName == usernameInput && i.PassWord == PasswordInput) {
                    message.text = "Admin successful login"
                    adminLogin=true
                }
            }
        if (studentLogin){
            val intent = Intent(this, StudentHomePageActivity::class.java).apply {
                putExtra("StudentID",studId)
            }
            startActivity(intent)
        }
        else if (adminLogin){
            val intent = Intent(this, AdminHomePageActivity::class.java)
            startActivity(intent)
        }
        else{
            message.text = "Username or Password Incorrect"


        }
        }
    }
}