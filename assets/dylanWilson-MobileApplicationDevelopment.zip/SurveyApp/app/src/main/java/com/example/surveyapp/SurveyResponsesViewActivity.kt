package com.example.surveyapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.ListviewClass
import com.example.surveyapp.model.ResponseviewClass
import com.example.surveyapp.model.mySurvey
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class SurveyResponsesViewActivity: AppCompatActivity(){
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.response_view)
        val myDataBase = mySurvey(this)

        var username: Array<String> = arrayOf("Username")
        var question: Array<String> = arrayOf("Question number","1","2","3","4","5","6","7","8","9","10")
        var answer: Array<String> = arrayOf("Answer")
        val allpublishedSurveys = myDataBase.getAllPublishedSurvey()
        val allAnswer = myDataBase.getAllAnswers()
        val allstudents= myDataBase.getAllStudents()
        val allquestions= myDataBase.getAllQuestions()

        val AllStudentSurveyResponds=myDataBase.getAllStudentSurveyResponds()
        var PublishedsurveyID=intent.getIntExtra("PSurveyId",0)
        for (i in AllStudentSurveyResponds){
            //Toast.makeText(applicationContext,i.PublishedSurveyId.toString(), Toast.LENGTH_SHORT).show()
            if(PublishedsurveyID==i.PublishedSurveyId){
                //Toast.makeText(applicationContext,"hi" , Toast.LENGTH_SHORT).show()
                for (j in allstudents){
                    if(j.Id==i.StudentId){
                        username+=j.LoginName

                    }


                    //Toast.makeText(applicationContext,questi, Toast.LENGTH_SHORT).show()

                for(j in allAnswer){
                    if(j.Id==i.AnswerId){
                        answer+=j.AnswerText
                    }
                }
                }
            }
        }


        var simpleList = findViewById<ListView>(R.id.responses)
        val customAdapter = ResponseviewClass(applicationContext, username, question, answer)
        simpleList!!.adapter = customAdapter

    }
}

