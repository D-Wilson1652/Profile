package com.example.surveyapp.model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.surveyapp.R

class DisplayListView (private val appContext: Context, private val ActiveSurveys: Array<String>,
                       private val NOParticipants: Array<Int>) : BaseAdapter() {

    private val inflater: LayoutInflater
            = appContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return ActiveSurveys.size
    }

    override fun getItem(i: Int): Any? {
        return i
    }

    override fun getItemId(i: Int): Long {
        return i.toLong()
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {

        var view: View? = view
        view = inflater.inflate(R.layout.display_active_surveys_list_view, parent, false)

        val mCode = view.findViewById<TextView>(R.id.active_surveys)
        val nStime = view.findViewById<TextView>(R.id.number_of_participants)

        mCode.text = ActiveSurveys[position]
        nStime.text = NOParticipants[position].toString()
        return view

    }

}