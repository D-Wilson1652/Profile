package com.example.surveyapp.model

data class Answer(val Id: Int, val AnswerText: String) {
}