package com.example.surveyapp.model

data class Survey(val Id: Int, val Title: String) {
}