package com.example.surveyapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.surveyapp.model.DisplayListView
import com.example.surveyapp.model.ListviewClass
import com.example.surveyapp.model.mySurvey
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*

class DisplayActiveSurveysActivity : AppCompatActivity(){
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.display_active_surveys)
        val myDataBase = mySurvey(this)
        var ActiveSurveys: Array<String> = arrayOf("Active Surveys")
        var NumberOfParticipants: Array<Int> = arrayOf(0)
        var allpublishedSurveys = myDataBase.getAllPublishedSurvey()
        var allSurveys = myDataBase.getAllSurveys()
        var allStudresp = myDataBase.getAllStudentSurveyResponds()
        val currentdate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))

        for (i in allpublishedSurveys) {
            var sdformat = SimpleDateFormat("dd/MM/yyyy")
            var CurrentDate: Date = sdformat.parse(currentdate)
            var StartDate: Date = sdformat.parse(i.StartDate)
            var EndDate: Date = sdformat.parse(i.EndDate)
            if (CurrentDate.compareTo(StartDate)>0 && CurrentDate.compareTo(EndDate)<0) {
                var tempvar=0
                for(j in allSurveys){
                    if(j.Id==i.SurveyId){
                        ActiveSurveys+=j.Title
                    }
                }
                for (k in allStudresp){
                    if(k.PublishedSurveyId==i.Id){
                        tempvar+=1
                        break
                    }
                }
                NumberOfParticipants+=tempvar
            }
        }
        var simpleList: ListView = findViewById<ListView>(R.id.displayActive)
        val customAdapter = DisplayListView(applicationContext, ActiveSurveys, NumberOfParticipants)
        simpleList!!.adapter = customAdapter}
}