package controller;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Set;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter; 
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import model.Course;
import model.Schedule;
import model.Module;
import model.StudentProfile;
import view.ModuleChooserRootPane;
import view.OverviewSelectionPane;
import view.ReserveModulesPane;
import view.SelectModulesPane;
import view.CreateStudentProfilePane;
import view.ModuleChooserMenuBar;

public class ModuleChooserController {

	//fields to be used throughout class
	private ModuleChooserRootPane view;
	private StudentProfile model;
	
	private CreateStudentProfilePane cspp;
	private SelectModulesPane smp;
	private ReserveModulesPane rmp;
	private OverviewSelectionPane osp;
	private ModuleChooserMenuBar mstmb;

	public ModuleChooserController(ModuleChooserRootPane view, StudentProfile model) {
		//initialise view and model fields
		this.view = view;
		this.model = model;
		
		//initialise view subcontainer fields
		cspp = view.getCreateStudentProfilePane();
		mstmb = view.getModuleSelectionToolMenuBar();
		smp = view.getSelectModulesPane();
		rmp = view.getReserveModulesPane();
		osp = view.getOverviewSelectionPane();
		//add courses to combobox in create student profile pane using the generateAndGetCourses helper method below
		cspp.addCoursesToComboBox(generateAndGetCourses());
		//attach event handlers to view using private helper method
		this.attachEventHandlers();	
	}

	
	//helper method - used to attach event handlers
	private void attachEventHandlers() {
		//attach an event handler to the create student profile pane
		cspp.addCreateStudentProfileHandler(new CreateStudentProfileHandler());
		smp.addAddSelectModulePage(e -> smp.addterm1credits(changeLimit(smp.getUnselectedTerm1List(),smp.getSelectedTerm1List(),60,smp.getTerm1Credits())));
		smp.addAdd2SelectModulePage(e -> smp.addterm2credits(changeLimit(smp.getUnselectedTerm2List(),smp.getSelectedTerm2List(),60,smp.getTerm2Credits())));
		smp.addRemoveSelectModulePage(e -> smp.addterm1credits(-changeLimit(smp.getSelectedTerm1List(),smp.getUnselectedTerm1List(),60,0)));
		smp.addRemove2SelectModulePage(e -> smp.addterm2credits(-changeLimit(smp.getSelectedTerm2List(),smp.getUnselectedTerm2List(),60,0)));
		smp.addResetSelectModulePage(new CreateStudentProfileHandler());
		smp.addSubmitSelectModulePage(new SubmitSelectModulePage());
		rmp.addAddReserveModulePage(e -> rmp.addReserve1Credits(changeLimit(rmp.getUnselectedTerm1List(),rmp.getReservedTerm1List(),30,rmp.getReserve1Credits())));
		rmp.addAdd2ReserveModulePage(e -> rmp.addReserve2Credits(changeLimit(rmp.getUnselectedTerm2List(),rmp.getReservedTerm2List(),30,rmp.getReserve2Credits())));
		rmp.addRemoveReserveModulePage(e -> rmp.addReserve1Credits(-changeNoLimit(rmp.getReservedTerm1List(),rmp.getUnselectedTerm1List(),30)));
		rmp.addRemove2ReserveModulePage(e -> rmp.addReserve2Credits(-changeNoLimit(rmp.getReservedTerm2List(),rmp.getUnselectedTerm2List(),30)));
		rmp.addConfirmReserveModulePage(new ConfirmReserveModulePage());
		rmp.addConfirm2ReserveModulePage(new Confirm2ReserveModulePage());
		osp.addSaveOverviewSelectionPage(new SaveOverviewSelectionPage());
		//attach an event handler to the menu bar that closes the application
		mstmb.addAboutHandler(new AboutHandler() );
		mstmb.addSaveHandler(new SaveHandler());
		mstmb.addLoadHandler(new LoadHandler());
		mstmb.addExitHandler(e -> System.exit(0));
	}
	
	private class CreateStudentProfileHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e)  {
			cspp.getStudentDate();
			cspp.getStudentEmail();
			cspp.getStudentName();
			cspp.getStudentPnumber();
			model.setStudentCourse(cspp.getSelectedCourse());
			model.setStudentEmail(cspp.getStudentEmail());
			model.setStudentName(cspp.getStudentName());
			model.setStudentPnumber(cspp.getStudentPnumber());
			model.setSubmissionDate(cspp.getStudentDate());
			model.clearSelectedModules();
			model.clearReservedModules();
			Module imat3423 = new Module("IMAT3423", "Systems Building: Methods", 15, true, Schedule.TERM_1);
			Module ctec3451 = new Module("CTEC3451", "Development Project", 30, true, Schedule.YEAR_LONG);
			Module ctec3902_SoftEng = new Module("CTEC3902", "Rigorous Systems", 15, true, Schedule.TERM_2);	
			Module ctec3902_CompSci = new Module("CTEC3902", "Rigorous Systems", 15, false, Schedule.TERM_2);
			Module ctec3110 = new Module("CTEC3110", "Secure Web Application Development", 15, false, Schedule.TERM_1);
			Module ctec3605 = new Module("CTEC3605", "Multi-service Networks 1", 15, false, Schedule.TERM_1);	
			Module ctec3606 = new Module("CTEC3606", "Multi-service Networks 2", 15, false, Schedule.TERM_2);	
			Module ctec3410 = new Module("CTEC3410", "Web Application Penetration Testing", 15, false, Schedule.TERM_2);
			Module ctec3904 = new Module("CTEC3904", "Functional Software Development", 15, false, Schedule.TERM_2);
			Module ctec3905 = new Module("CTEC3905", "Front-End Web Development", 15, false, Schedule.TERM_2);
			Module ctec3906 = new Module("CTEC3906", "Interaction Design", 15, false, Schedule.TERM_1);
			Module ctec3911 = new Module("CTEC3911", "Mobile Application Development", 15, false, Schedule.TERM_1);
			Module imat3410 = new Module("IMAT3104", "Database Management and Programming", 15, false, Schedule.TERM_2);
			Module imat3406 = new Module("IMAT3406", "Fuzzy Logic and Knowledge Based Systems", 15, false, Schedule.TERM_1);
			Module imat3611 = new Module("IMAT3611", "Computer Ethics and Privacy", 15, false, Schedule.TERM_1);
			Module imat3613 = new Module("IMAT3613", "Data Mining", 15, false, Schedule.TERM_1);
			Module imat3614 = new Module("IMAT3614", "Big Data and Business Models", 15, false, Schedule.TERM_2); 
			Module imat3428_CompSci = new Module("IMAT3428", "Information Technology Services Practice", 15, false, Schedule.TERM_2);
			ArrayList<Module> mods= new ArrayList<Module>();
			mods.add(imat3423);
			mods.add(ctec3451);
			mods.add(ctec3902_SoftEng);
			mods.add(ctec3902_CompSci);
			mods.add(ctec3110);
			mods.add(ctec3605);
			mods.add(ctec3606);
			mods.add(ctec3410);
			mods.add(ctec3904);
			mods.add(ctec3905);
			mods.add(ctec3906);
			mods.add(ctec3911);
			mods.add(imat3410);
			mods.add(imat3406);
			mods.add(imat3611);
			mods.add(imat3613);
			mods.add(imat3614);
			mods.add(imat3428_CompSci);
			Course UST1T = new Course("1");
			Course UST2T = new Course("2");
			Course ST1T = new Course("3");
			Course ST2T = new Course("4");
			Course SYLT = new Course("5");
			int currentCredits=0;
			int currentCredits2=0;
			if (model.getStudentCourse().getCourseName()=="Software Engineering") {
				mods.remove(ctec3902_CompSci);
				mods.remove(imat3428_CompSci);
			}
			if (model.getStudentCourse().getCourseName()=="Computer Science") {
				mods.remove(ctec3902_SoftEng);
			}
			for (Module x : mods) {
				if (x.getDelivery()==Schedule.TERM_1) {
					if (x.isMandatory()==true) {
						ST1T.addModuleToCourse(x);
						currentCredits=currentCredits+x.getModuleCredits();
					}
					else
						UST1T.addModuleToCourse(x);
				}
				if (x.getDelivery()==Schedule.TERM_2) {
					if (x.isMandatory()==true) {
						ST2T.addModuleToCourse(x);
						currentCredits2=currentCredits2+x.getModuleCredits();
					}
					else
						UST2T.addModuleToCourse(x);
				}
				if (x.getDelivery()==Schedule.YEAR_LONG){
					SYLT.addModuleToCourse(x);
					currentCredits=currentCredits+(x.getModuleCredits()/2);
					currentCredits2=currentCredits2+(x.getModuleCredits()/2);

				}
			}
			smp.PopulateUnselectedTerm1List((UST1T.getAllModulesOnCourse()));
			smp.PopulateUnselectedTerm2List((UST2T.getAllModulesOnCourse()));
			smp.PopulateSelectedTerm1List((ST1T.getAllModulesOnCourse()));
			smp.PopulateSelectedTerm2List((ST2T.getAllModulesOnCourse()));
			smp.PopulateSelectedYearLongList((SYLT.getAllModulesOnCourse()));
			smp.ResetCredit(currentCredits, currentCredits2);
			view.setT2();
			view.changeTab(1);
			}
		}

	private class SubmitSelectModulePage implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e)  {
			if (smp.getTerm1Credits()==60 && smp.getTerm2Credits()==60) {
			ObservableList<Module> selectyearmodules = smp.getSelectedYearLongContents();
			ObservableList<Module> select1modules = smp.getSelectedTerm1Contents();
			ObservableList<Module> select2modules = smp.getSelectedTerm2Contents();
			for (Module x:selectyearmodules) {
				model.addSelectedModule(x);
			}
			for (Module x:select1modules) {
				model.addSelectedModule(x);
			}
			for (Module x:select2modules) {
				model.addSelectedModule(x);
			}
			rmp.PopulateUnselectedTerm1List(smp.getUnselectedTerm1Contents());
			rmp.PopulateUnselectedTerm2List(smp.getUnselectedTerm2Contents());
			view.setT3();
			view.changeTab(2);
			}
		}
	}
	private class SaveHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e)  {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("UserModuleObj.dat"));) {
			oos.writeObject(model.getStudentPnumber()+model.getStudentName()+model.getStudentCourse()+model.getStudentEmail()+model.getSubmissionDate());
			for (Module x : model.getAllSelectedModules()) {
				oos.writeObject(x);
				}
			for (Module y : model.getAllReservedModules()) {
				oos.writeObject(y);
			}
			oos.writeObject(null);
			oos.flush();
		}
		catch(IOException ioExcep){
			System.out.print("error");
		}
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Module Chooser Load");
		alert.setHeaderText("Module Chooser Year 2 Coursework");
		alert.setContentText("Saved");
		alert.showAndWait();
		}
	}
	
	private class LoadHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e)  {
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("registerObj.dat"));) {

				 // this is where i got to
				Module n = null;
				Module m = null;
				
				while ((n = (Module) ois.readObject()) != null) {
					model.addSelectedModule(n);
					
				}	
				while ((m = (Module) ois.readObject()) != null) {
					model.addReservedModule(m);
				}	
				
				
				ois.close(); 
			}
			catch (IOException ioExcep){
				System.out.println("Error loading");
			}
			catch (ClassNotFoundException c) {
				System.out.println("Class Not found");
			}

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Module Chooser Load");
			alert.setHeaderText("Module Chooser Year 2 Coursework");
			alert.setContentText("Save?");
			alert.showAndWait();
			
		}
	}
	private class ConfirmReserveModulePage implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e)  {
			if (rmp.getReserve1Credits()==30 && rmp.getReserve2Credits() !=30) {
				rmp.setExpandedPane(rmp.getT2Panel());
			}
			if (rmp.getReserve1Credits()==30 && rmp.getReserve2Credits() ==30) {
				ObservableList<Module> reserve1modules = rmp.getReservedTerm1Contents();
				ObservableList<Module> reserve2modules = rmp.getReservedTerm2Contents();				
				for (Module x:reserve1modules) {
					model.addReservedModule(x);
				}
				for (Module x:reserve2modules) {
					model.addReservedModule(x);
				}
				String profileString = "";
				String SelectString = "";
				String ReserveString = "";
				profileString=(profileString+"Name: "+model.getStudentName().getFullName()+
						"\nPNo: "+model.getStudentPnumber()+
						"\nEmail: "+model.getStudentEmail()+
						"\nDate: "+model.getSubmissionDate()+
						"\nCourse: "+model.getStudentCourse());
				SelectString=(SelectString+"Selected modules:\n===========\n");
				ReserveString=(ReserveString+"Reserved modules:\n===========\n");
				SelectString=(SelectString+CreateModuleString(model.getAllSelectedModules()));
				ReserveString=(ReserveString+CreateModuleString(model.getAllReservedModules()));
				osp.populateProfileView(profileString);
				osp.populateSelectView(SelectString);
				osp.populateReserveView(ReserveString);
				view.setT4();
				view.changeTab(3);

			}
			}
		
	}
	private class Confirm2ReserveModulePage implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e)  {
			if (rmp.getReserve1Credits()!=30 && rmp.getReserve2Credits() ==30) {
				rmp.setExpandedPane(rmp.getT1Panel());
			}
			if (rmp.getReserve1Credits()==30 && rmp.getReserve2Credits() ==30) {
				ObservableList<Module> reserve1modules = rmp.getReservedTerm1Contents();
				ObservableList<Module> reserve2modules = rmp.getReservedTerm2Contents();				
				for (Module x:reserve1modules) {
					model.addReservedModule(x);
				}
				for (Module x:reserve2modules) {
					model.addReservedModule(x);
				}
				String profileString = "";
				String SelectString = "";
				String ReserveString = "";
				profileString=(profileString+"Name: "+model.getStudentName().getFullName()+
						"\nPNo: "+model.getStudentPnumber()+
						"\nEmail: "+model.getStudentEmail()+
						"\nDate: "+model.getSubmissionDate()+
						"\nCourse: "+model.getStudentCourse());
				SelectString=(SelectString+"Selected modules:\n===========\n");
				ReserveString=(ReserveString+"Reserved modules:\n===========\n");
				SelectString=(SelectString+CreateModuleString(model.getAllSelectedModules()));
				ReserveString=(ReserveString+CreateModuleString(model.getAllReservedModules()));
				osp.populateProfileView(profileString);
				osp.populateSelectView(SelectString);
				osp.populateReserveView(ReserveString);
				view.setT4();
				view.changeTab(3);
				}
		}
	}
	private class AboutHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e)  {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Module Chooser About");
			alert.setHeaderText("Module Chooser Year 2 Coursework");
			alert.setContentText("This application allows you to select your first choice modules and your reserve module for next year.");
			alert.showAndWait();
		}
	}
	private class SaveOverviewSelectionPage implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e){
			PrintWriter writer;// the save handler will only work if you put in a suitable location for the file therefore i have used the most common c:\\ drive to make sure the assessors version works. please look for the txt file in your C:\\ drive
			try {
				writer = new PrintWriter(new File("C:\\"+model.getStudentPnumber()+"_Students_Overview.txt"));
				writer.write(osp.getProfileViewText()+""+osp.getSelectedViewText()+osp.getReservedViewText());
				writer.flush();
				writer.close();
			} 
			catch (FileNotFoundException e1) {
				e1.printStackTrace();
				System.out.print("Error In Saving");
			}
		}
	}
	
// local methods to minimise repeating the same code. the add and remove buttons all go through 2 methods which saves writing the code 6 more times
	private Course[] generateAndGetCourses() {
		Module imat3423 = new Module("IMAT3423", "Systems Building: Methods", 15, true, Schedule.TERM_1);
		Module ctec3451 = new Module("CTEC3451", "Development Project", 30, true, Schedule.YEAR_LONG);
		Module ctec3902_SoftEng = new Module("CTEC3902", "Rigorous Systems", 15, true, Schedule.TERM_2);	
		Module ctec3902_CompSci = new Module("CTEC3902", "Rigorous Systems", 15, false, Schedule.TERM_2);
		Module ctec3110 = new Module("CTEC3110", "Secure Web Application Development", 15, false, Schedule.TERM_1);
		Module ctec3605 = new Module("CTEC3605", "Multi-service Networks 1", 15, false, Schedule.TERM_1);	
		Module ctec3606 = new Module("CTEC3606", "Multi-service Networks 2", 15, false, Schedule.TERM_2);	
		Module ctec3410 = new Module("CTEC3410", "Web Application Penetration Testing", 15, false, Schedule.TERM_2);
		Module ctec3904 = new Module("CTEC3904", "Functional Software Development", 15, false, Schedule.TERM_2);
		Module ctec3905 = new Module("CTEC3905", "Front-End Web Development", 15, false, Schedule.TERM_2);
		Module ctec3906 = new Module("CTEC3906", "Interaction Design", 15, false, Schedule.TERM_1);
		Module ctec3911 = new Module("CTEC3911", "Mobile Application Development", 15, false, Schedule.TERM_1);
		Module imat3410 = new Module("IMAT3104", "Database Management and Programming", 15, false, Schedule.TERM_2);
		Module imat3406 = new Module("IMAT3406", "Fuzzy Logic and Knowledge Based Systems", 15, false, Schedule.TERM_1);
		Module imat3611 = new Module("IMAT3611", "Computer Ethics and Privacy", 15, false, Schedule.TERM_1);
		Module imat3613 = new Module("IMAT3613", "Data Mining", 15, false, Schedule.TERM_1);
		Module imat3614 = new Module("IMAT3614", "Big Data and Business Models", 15, false, Schedule.TERM_2);
		Module imat3428_CompSci = new Module("IMAT3428", "Information Technology Services Practice", 15, false, Schedule.TERM_2);


		Course compSci = new Course("Computer Science");
		compSci.addModuleToCourse(imat3423);
		compSci.addModuleToCourse(ctec3451);
		compSci.addModuleToCourse(ctec3902_CompSci);
		compSci.addModuleToCourse(ctec3110);
		compSci.addModuleToCourse(ctec3605);
		compSci.addModuleToCourse(ctec3606);
		compSci.addModuleToCourse(ctec3410);
		compSci.addModuleToCourse(ctec3904);
		compSci.addModuleToCourse(ctec3905);
		compSci.addModuleToCourse(ctec3906);
		compSci.addModuleToCourse(ctec3911);
		compSci.addModuleToCourse(imat3410);
		compSci.addModuleToCourse(imat3406);
		compSci.addModuleToCourse(imat3611);
		compSci.addModuleToCourse(imat3613);
		compSci.addModuleToCourse(imat3614);
		compSci.addModuleToCourse(imat3428_CompSci);

		Course softEng = new Course("Software Engineering");
		softEng.addModuleToCourse(imat3423);
		softEng.addModuleToCourse(ctec3451);
		softEng.addModuleToCourse(ctec3902_SoftEng);
		softEng.addModuleToCourse(ctec3110);
		softEng.addModuleToCourse(ctec3605);
		softEng.addModuleToCourse(ctec3606);
		softEng.addModuleToCourse(ctec3410);
		softEng.addModuleToCourse(ctec3904);
		softEng.addModuleToCourse(ctec3905);
		softEng.addModuleToCourse(ctec3906);
		softEng.addModuleToCourse(ctec3911);
		softEng.addModuleToCourse(imat3410);
		softEng.addModuleToCourse(imat3406);
		softEng.addModuleToCourse(imat3611);
		softEng.addModuleToCourse(imat3613);
		softEng.addModuleToCourse(imat3614);

		Course[] courses = new Course[2];
		courses[0] = compSci;
		courses[1] = softEng;

		return courses;
	}
	private int changeLimit(ListView<Module> removeList,ListView<Module> addList, int creditcap,int currentcredits ) {
		int index = removeList.getSelectionModel().getSelectedIndex();
		if(index!=-1) {
			Module courses=removeList.getSelectionModel().getSelectedItem();
			if (courses.isMandatory()==false) {
				if (courses.getModuleCredits()+currentcredits<=creditcap) {
					removeList.getItems().remove(courses);
					addList.getItems().add(courses);
					return courses.getModuleCredits();
					}
			}
	}
		return 0;

	}
	private int changeNoLimit(ListView<Module> removeList,ListView<Module> addList, int creditcap) {
		int index = removeList.getSelectionModel().getSelectedIndex();
		if(index!=-1) {
			Module courses=removeList.getSelectionModel().getSelectedItem();
			removeList.getItems().remove(courses);
			addList.getItems().add(courses);
			return courses.getModuleCredits();
				}
	
		return 0;
	}
	private String CreateModuleString(Set<Module>Modules) {
		String modulesString="";
		for (Module x:Modules) {
			String mandatory="";
			String delivery = "";
			if (x.isMandatory()==true) {
				mandatory="yes";
			}
			else {
				mandatory="no";
			}
			if(x.getDelivery()==Schedule.TERM_1) {
				delivery="1";
			}
			if(x.getDelivery()==Schedule.TERM_2) {
				delivery="2";
			}
			if(x.getDelivery()==Schedule.YEAR_LONG) {
				delivery="1 and 2";
			}
			modulesString=(modulesString+"Module code: "+x.getModuleCode()+
					", Module name: "+x.getModuleName()+
					"\n Credits: "+x.getModuleCredits()+
					", Mandatory on your course? "+mandatory+
					", Delivery:term "+delivery+"\n\n");
			} 
		return modulesString;
		}
}
