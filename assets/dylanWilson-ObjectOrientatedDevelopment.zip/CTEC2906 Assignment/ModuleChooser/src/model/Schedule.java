package model;

public enum Schedule {
	TERM_1, TERM_2, YEAR_LONG
}
