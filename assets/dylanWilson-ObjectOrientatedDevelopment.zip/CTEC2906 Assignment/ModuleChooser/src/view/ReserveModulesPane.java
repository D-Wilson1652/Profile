package view;

import java.util.Collection;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import model.Module;

public class ReserveModulesPane extends Accordion {
	private ListView<Module> UnselectedTerm1Modules,ReservedTerm1Modules,UnselectedTerm2Modules,ReservedTerm2Modules;
	private GridPane ReserveTerm1Pane,ReserveTerm2Pane,ReserveModulesPane,ReserveModulesPane2;
	private TitledPane t1, t2; //declared as fields so they can be accessed to expand in method below
	private Button btnAdd, btnRemove, btnConfirm,btnAdd2, btnRemove2, btnConfirm2;
	private ObservableList<Module> UnselectedTerm1Text,UnselectedTerm2Text,ReservedTerm1Text,ReservedTerm2Text;
	private HBox AddRemoveAndConfirm,AddRemoveAndConfirm2;
	private int reservecredits,reservecredits2;
	public ReserveModulesPane() {
		//styling
		this.setPadding(new Insets(20,20,20,20));
		// initialising
		Label Reserve=new Label("Reserve 30 credits worth of term 1 modules ");
		Label Reserve2=new Label("Reserve 30 credits worth of term 2 modules ");
		Label UnSelTerm1 =new Label("Unselected Term 1 modules");
		Label ResTerm1 =new Label("Reserveded Term 1 modules");
		Label UnSelTerm2 =new Label("Unselected Term 2 modules");
		Label ResTerm2 =new Label("Reserveded Term 2 modules");
		
		reservecredits=0;
		reservecredits2=0;
		
		AddRemoveAndConfirm=new HBox();		
		AddRemoveAndConfirm2 = new HBox();
		btnAdd = new Button("Add");
		btnRemove = new Button("Remove");
		btnConfirm = new Button("Confirm");
		btnAdd2 = new Button("Add");
		btnRemove2 = new Button("Remove");
		btnConfirm2= new Button("Confirm");
		
		ReserveTerm1Pane = new GridPane();
		ReserveTerm2Pane = new GridPane();
		ReserveModulesPane= new GridPane();
		ReserveModulesPane2= new GridPane();
		
		ColumnConstraints column0 = new ColumnConstraints();
		ColumnConstraints column1 = new ColumnConstraints();
		ColumnConstraints column2 = new ColumnConstraints();
		ColumnConstraints column3 = new ColumnConstraints();
		
		UnselectedTerm1Text = FXCollections.observableArrayList();
		UnselectedTerm2Text = FXCollections.observableArrayList();
		ReservedTerm1Text =FXCollections.observableArrayList();
		ReservedTerm2Text =FXCollections.observableArrayList();
		
		UnselectedTerm1Modules=new ListView<Module>(UnselectedTerm1Text);
		UnselectedTerm2Modules=new ListView<Module>(UnselectedTerm2Text);
		ReservedTerm1Modules=new ListView<Module>(ReservedTerm1Text);
		ReservedTerm2Modules=new ListView<Module>(ReservedTerm2Text);
		
		UnselectedTerm1Modules.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		UnselectedTerm2Modules.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		ReservedTerm1Modules.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		ReservedTerm2Modules.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		
		t1 = new TitledPane("Term 1 modules", ReserveModulesPane);
		t2 = new TitledPane("Term 2 modules", ReserveModulesPane2);
		//buttons
		
		AddRemoveAndConfirm.setSpacing(15);
		AddRemoveAndConfirm.setAlignment(Pos.CENTER);
		AddRemoveAndConfirm2.setSpacing(15);
		AddRemoveAndConfirm2.setAlignment(Pos.CENTER);
		btnAdd.setPrefSize(70, 15);
		btnRemove.setPrefSize(70, 15);
		btnConfirm.setPrefSize(70, 15);	
		btnAdd2.setPrefSize(70, 15);
		btnRemove2.setPrefSize(70, 15);
		btnConfirm2.setPrefSize(70, 15);
		
		
		AddRemoveAndConfirm.getChildren().addAll(Reserve,btnAdd, btnRemove,btnConfirm);
		AddRemoveAndConfirm2.getChildren().addAll(Reserve2,btnAdd2, btnRemove2,btnConfirm2);
		//Buttons
		//listviews
		
		ReserveTerm1Pane.setHgap(20);
		ReserveTerm1Pane.setAlignment(Pos.CENTER);
		column0.setHalignment(HPos.LEFT);
		column1.setHalignment(HPos.LEFT);
		column2.setHalignment(HPos.LEFT);
		column3.setHalignment(HPos.LEFT);
		ReserveTerm2Pane.setHgap(20);
		ReserveModulesPane.setVgap(20);
		ReserveModulesPane2.setVgap(20);
		ReserveTerm2Pane.setAlignment(Pos.CENTER);
		ReserveModulesPane.setAlignment(Pos.CENTER);
		ReserveModulesPane2.setAlignment(Pos.CENTER);
		
		ReserveTerm1Pane.getColumnConstraints().addAll(column0);
		ReserveTerm2Pane.getColumnConstraints().addAll(column1);
		ReserveModulesPane2.getColumnConstraints().addAll(column2);
		ReserveModulesPane2.getColumnConstraints().addAll(column3);
		ReserveModulesPane.setPadding(new Insets(40,40,40,40));
		ReserveModulesPane2.setPadding(new Insets(40,40,40,40));
		
		UnselectedTerm1Modules.setPrefSize(400, 375);
		ReservedTerm1Modules.setPrefSize(400, 375);
		UnselectedTerm2Modules.setPrefSize(400, 375);
		ReservedTerm2Modules.setPrefSize(400, 375);
		GridPane.setHgrow(ReserveTerm1Pane, Priority.ALWAYS);
		GridPane.setHgrow(UnselectedTerm1Modules, Priority.ALWAYS);
		GridPane.setHgrow(ReservedTerm1Modules, Priority.ALWAYS);
		GridPane.setHgrow(UnselectedTerm2Modules, Priority.ALWAYS);
		GridPane.setHgrow(ReservedTerm2Modules, Priority.ALWAYS);
		GridPane.setHgrow(ReserveTerm2Pane, Priority.ALWAYS);
		GridPane.setHgrow(ReserveModulesPane2, Priority.ALWAYS);
		GridPane.setHgrow(ReserveModulesPane, Priority.ALWAYS);
		GridPane.setVgrow(ReserveTerm1Pane, Priority.ALWAYS);
		GridPane.setVgrow(UnselectedTerm1Modules, Priority.ALWAYS);
		GridPane.setVgrow(ReservedTerm1Modules, Priority.ALWAYS);
		GridPane.setVgrow(UnselectedTerm2Modules, Priority.ALWAYS);
		GridPane.setVgrow(ReservedTerm2Modules, Priority.ALWAYS);
		GridPane.setVgrow(ReserveTerm2Pane, Priority.ALWAYS);
		GridPane.setVgrow(ReserveModulesPane2, Priority.ALWAYS);
		GridPane.setVgrow(ReserveModulesPane, Priority.ALWAYS);

		//listviews
		//create labels
		ReserveTerm1Pane.add(UnSelTerm1, 0, 0);
		ReserveTerm1Pane.add(UnselectedTerm1Modules, 0, 1);
		ReserveTerm1Pane.add(ResTerm1, 1, 0);
		ReserveTerm1Pane.add(ReservedTerm1Modules, 1, 1);
		ReserveTerm2Pane.add(UnSelTerm2, 0, 0);
		ReserveTerm2Pane.add(UnselectedTerm2Modules, 0, 1);
		ReserveTerm2Pane.add(ResTerm2, 1, 0);
		ReserveTerm2Pane.add(ReservedTerm2Modules, 1, 1);
		ReserveModulesPane.add(ReserveTerm1Pane, 0, 0);
		ReserveModulesPane.add(AddRemoveAndConfirm, 0, 1);
		ReserveModulesPane2.add(ReserveTerm2Pane, 0, 0);
		ReserveModulesPane2.add(AddRemoveAndConfirm2, 0, 1);
		
		this.getPanes().addAll(t1, t2);
		this.setExpandedPane(t1);

	}
	public ObservableList<Module> getUnselectedTerm1Contents() {
		return 	UnselectedTerm1Text;
	}
	public ObservableList<Module> getUnselectedTerm2Contents() {
		return 	UnselectedTerm2Text;
	}
	public ObservableList<Module> getReservedTerm1Contents() {
		return 	ReservedTerm1Text;
	}
	public ObservableList<Module> getReservedTerm2Contents() {
		return 	ReservedTerm2Text;
	}
	public ListView<Module> getUnselectedTerm1List() {
		return 	UnselectedTerm1Modules;
	}
	public ListView<Module> getUnselectedTerm2List() {
		return 	UnselectedTerm2Modules;
	}	
	public ListView<Module> getReservedTerm1List() {
		return 	ReservedTerm1Modules;
	}
	public ListView<Module> getReservedTerm2List() {
		return 	ReservedTerm2Modules;
	}
	
	public TitledPane getT1Panel() {
		return t1;
	}
	public TitledPane getT2Panel() {
		return t2;
	}	
	public void PopulateUnselectedTerm1List(Collection<Module> x) {
		UnselectedTerm1Text.setAll(x);
	}
	public void PopulateUnselectedTerm2List(Collection<Module> x) {
		UnselectedTerm2Text.setAll(x);
	}
	
	public void addAddReserveModulePage(EventHandler<ActionEvent> handler) {
		btnAdd.setOnAction(handler);
	}
	public void addRemoveReserveModulePage(EventHandler<ActionEvent> handler) {
		btnRemove.setOnAction(handler);
	}
	public void addAdd2ReserveModulePage(EventHandler<ActionEvent> handler) {
		btnAdd2.setOnAction(handler);
	}
	public void addRemove2ReserveModulePage(EventHandler<ActionEvent> handler) {
		btnRemove2.setOnAction(handler);
	}	
	public void addConfirmReserveModulePage(EventHandler<ActionEvent> handler) {
		btnConfirm.setOnAction(handler);
	}
	public void addConfirm2ReserveModulePage(EventHandler<ActionEvent> handler) {
		btnConfirm2.setOnAction(handler);
	}
	
	public int getReserve1Credits() {
		return reservecredits;
	}
	public int getReserve2Credits() {
		return reservecredits2;
	}
	public void addReserve1Credits(int x) {
		reservecredits=reservecredits+x;
	}
	public void addReserve2Credits(int x) {
		reservecredits2=reservecredits2+x;
	}
	
	
}
