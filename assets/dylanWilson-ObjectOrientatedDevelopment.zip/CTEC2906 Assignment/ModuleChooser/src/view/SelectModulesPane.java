package view;

import java.util.Collection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import model.Module;

public class SelectModulesPane extends GridPane {
	private Button btnAdd, btnRemove, btnAdd2, btnRemove2,btnReset,btnSubmit;
	private HBox Term1AddAndRemove,Term2AddAndRemove,CurrentCredits,CurrentCredits2,CurrentCreditsAll,ResetAndSubmit;
	private TextField CurrentTerm1Credits,CurrentTerm2Credits;
	private ListView<Module> UnselectedTerm1Modules, UnselectedTerm2Modules,SelectedModulesList,SelectedTerm1ModulesList,SelectedTerm2ModulesList;
	private GridPane SelectModulePane,SelectModulePane2,SelectModulePaneCombine,SelectedModules,SelectedTerm1Modules,SelectedTerm2Modules;
	private ObservableList<Module> UnselectedTerm1Text,UnselectedTerm2Text,SelectedTerm1Text,SelectedTerm2Text,SelectedYearLongText;
	private int Term2Credits,Term1Credits;
	public SelectModulesPane() {
		//styling
		Term1AddAndRemove=new HBox();
		Term2AddAndRemove=new HBox();
		CurrentCredits=new HBox();
		CurrentCredits2=new HBox();
		CurrentCreditsAll=new HBox();
		ResetAndSubmit=new HBox();
		
		btnAdd2 = new Button("Add");
		btnRemove2 = new Button("Remove");
		btnAdd = new Button("Add");
		btnRemove = new Button("Remove");
		btnReset = new Button("Reset");
		btnSubmit = new Button("Submit");
		btnReset = new Button("Reset");
		btnSubmit = new Button("Submit");
		
		SelectModulePane = new GridPane();
		SelectModulePane2 = new GridPane();
		SelectModulePaneCombine = new GridPane();
		SelectedModules = new GridPane();
		SelectedTerm1Modules = new GridPane();
		SelectedTerm2Modules = new GridPane();
		
		Label textLabel = new Label("Term 1");
		Label textLabel2 = new Label("Term 2");
		Label CurrentTerm1 = new Label("Current term 1 credits:");
		Label CurrentTerm2 = new Label("Current term 2 credits:");
		Label lblTerm1Mod = new Label("Unselected Term 1 modules");
		Label lblTerm2Mod =new Label("Unselected Term 2 modules");
		Label SelTermMod =new Label("Select Year Long modules");
		Label SelTerm1 =new Label("Select Term 1 modules");
		Label SelTerm2 =new Label("Select Term 2 modules");
		
		Term1Credits=0;
		Term2Credits=0;
		
		CurrentTerm1Credits = new TextField(String.valueOf(Term1Credits));
		CurrentTerm2Credits = new TextField(String.valueOf(Term2Credits));
		
		UnselectedTerm1Text = FXCollections.observableArrayList();
		UnselectedTerm2Text = FXCollections.observableArrayList();
		SelectedTerm1Text = FXCollections.observableArrayList();
		SelectedTerm2Text = FXCollections.observableArrayList();
		SelectedYearLongText = FXCollections.observableArrayList();
		
		UnselectedTerm1Modules = new ListView<Module>(UnselectedTerm1Text);
		UnselectedTerm2Modules = new ListView<Module>(UnselectedTerm2Text);
		SelectedModulesList = new ListView<Module>(SelectedYearLongText);
		SelectedTerm1ModulesList = new ListView<Module>(SelectedTerm1Text);
		SelectedTerm2ModulesList = new ListView<Module>(SelectedTerm2Text);
		
		UnselectedTerm1Modules.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		UnselectedTerm2Modules.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		SelectedModulesList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		SelectedTerm1ModulesList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		SelectedTerm2ModulesList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

		Term1AddAndRemove.setPadding(new Insets(20,0,20,0));
		Term1AddAndRemove.setSpacing(15);
		Term1AddAndRemove.setAlignment(Pos.CENTER);
		Term2AddAndRemove.setPadding(new Insets(20,0,20,0));
		Term2AddAndRemove.setSpacing(15);
		Term2AddAndRemove.setAlignment(Pos.CENTER);
		CurrentCredits.setSpacing(15);
		CurrentCredits.setAlignment(Pos.CENTER);
		CurrentCredits2.setSpacing(15);
		CurrentCredits2.setAlignment(Pos.CENTER);
		ResetAndSubmit.setSpacing(30);
		ResetAndSubmit.setAlignment(Pos.CENTER);
		ResetAndSubmit.setPadding(new Insets(15,0,15,0));
		SelectModulePane.setHgap(30);
		SelectModulePane.setAlignment(Pos.CENTER);
		
		CurrentTerm1Credits.setEditable(false);
		CurrentTerm1Credits.setMaxSize(60, 15);
		CurrentTerm2Credits.setEditable(false);
		CurrentTerm2Credits.setMaxSize(60, 15);
		
		CurrentCreditsAll.setSpacing(160);
		CurrentCreditsAll.setAlignment(Pos.CENTER);
		CurrentCreditsAll.setPadding(new Insets(10,0,10,0));

		
		SelectModulePane2.setVgap(15);
		SelectedModules.setAlignment(Pos.CENTER);
		SelectedTerm1Modules.setAlignment(Pos.CENTER);
		SelectedTerm2Modules.setAlignment(Pos.CENTER);

		SelectModulePane2.setPadding(new Insets(0,0,0,10));
		SelectModulePane2.setAlignment(Pos.CENTER);
		
		SelectModulePaneCombine.setVgap(10);
		SelectModulePaneCombine.setHgap(15);
		SelectModulePaneCombine.setAlignment(Pos.CENTER);
		
		ColumnConstraints column0 = new ColumnConstraints();
		column0.setHalignment(HPos.LEFT);
		
		btnAdd.setPrefSize(70, 15);
		btnRemove.setPrefSize(70, 15);
		btnAdd2.setPrefSize(70, 15);
		btnRemove2.setPrefSize(70, 15);
		btnReset.setPrefSize(70, 15);
		btnSubmit.setPrefSize(70, 15);
		UnselectedTerm1Modules.setPrefSize(400, 150);
		UnselectedTerm2Modules.setPrefSize(400, 150);
		SelectedModulesList.setPrefSize(400, 75);
		SelectedTerm2ModulesList.setPrefSize(400, 150);
		SelectedTerm1ModulesList.setPrefSize(400, 150);
		
		Term1AddAndRemove.getChildren().addAll(textLabel, btnAdd, btnRemove);		
		Term2AddAndRemove.getChildren().addAll(textLabel2, btnAdd2, btnRemove2);
		ResetAndSubmit.getChildren().addAll(btnReset, btnSubmit);
		CurrentCredits.getChildren().addAll(CurrentTerm1,CurrentTerm1Credits);
		CurrentCredits2.getChildren().addAll(CurrentTerm2,CurrentTerm2Credits);
		CurrentCreditsAll.getChildren().addAll(CurrentCredits,CurrentCredits2);
		
		GridPane.setHgrow(UnselectedTerm1Modules, Priority.ALWAYS);
		GridPane.setHgrow(UnselectedTerm2Modules, Priority.ALWAYS);
		GridPane.setHgrow(SelectedTerm1ModulesList, Priority.ALWAYS);
		GridPane.setHgrow(SelectedTerm2ModulesList, Priority.ALWAYS);
		GridPane.setVgrow(UnselectedTerm1Modules, Priority.ALWAYS);
		GridPane.setVgrow(UnselectedTerm2Modules, Priority.ALWAYS);
		GridPane.setVgrow(SelectedTerm1ModulesList, Priority.ALWAYS);
		GridPane.setVgrow(SelectedTerm2ModulesList, Priority.ALWAYS);
		
		
		GridPane.setHgrow(SelectModulePaneCombine, Priority.ALWAYS);
		GridPane.setHgrow(SelectModulePane, Priority.ALWAYS);
		GridPane.setHgrow(SelectModulePane2, Priority.ALWAYS);
		GridPane.setHgrow(SelectedTerm1Modules, Priority.ALWAYS);
		GridPane.setHgrow(SelectedTerm2Modules, Priority.ALWAYS);
		GridPane.setHgrow(SelectedModulesList, Priority.ALWAYS);
		GridPane.setVgrow(SelectModulePaneCombine, Priority.ALWAYS);
		GridPane.setVgrow(SelectModulePane, Priority.ALWAYS);
		GridPane.setVgrow(SelectModulePane2, Priority.ALWAYS);
		GridPane.setVgrow(SelectedTerm1Modules, Priority.ALWAYS);
		GridPane.setVgrow(SelectedTerm2Modules, Priority.ALWAYS);
		
		//add
		SelectModulePane.add(lblTerm1Mod,0,0);
		SelectModulePane.add(UnselectedTerm1Modules, 0, 1);
		SelectModulePane.add(Term1AddAndRemove, 0, 2);
		SelectModulePane.add(lblTerm2Mod, 0, 4);
		SelectModulePane.add(UnselectedTerm2Modules, 0, 5);
		SelectModulePane.add(Term2AddAndRemove, 0, 6);
		SelectedTerm2Modules.add(SelTerm2, 0,0);
		SelectedTerm2Modules.add(SelectedTerm2ModulesList, 0,1);
		SelectedModules.add(SelTermMod,0,0);
		SelectedModules.add(SelectedModulesList, 0,1);
		SelectedTerm1Modules.add(SelTerm1, 0,0);
		SelectedTerm1Modules.add(SelectedTerm1ModulesList, 0,1);
		SelectModulePane2.add(SelectedModules, 0, 0);
		SelectModulePane2.add(SelectedTerm1Modules, 0, 1);
		SelectModulePane2.add(SelectedTerm2Modules, 0, 2);
		SelectModulePaneCombine.add(SelectModulePane, 0, 0);
		SelectModulePaneCombine.add(SelectModulePane2, 1, 0);
		
		this.setAlignment(Pos.CENTER);
		ColumnConstraints column1 = new ColumnConstraints();
		column1.setHalignment(HPos.CENTER);
		this.setPadding(new Insets(20,20,20,20));
		this.getColumnConstraints().addAll(column1);
		this.add(SelectModulePaneCombine, 0, 0);
		this.add(CurrentCreditsAll, 0, 1);
		this.add(ResetAndSubmit, 0, 2);
	}
	
	public ObservableList<Module> getSelectedYearLongContents() {
		return 	SelectedYearLongText;
	}
	public ObservableList<Module> getUnselectedTerm1Contents() {
		return 	UnselectedTerm1Text;
	}
	public ObservableList<Module> getUnselectedTerm2Contents() {
		return 	UnselectedTerm2Text;
	}
	public ObservableList<Module> getSelectedTerm1Contents() {
		return 	SelectedTerm1Text;
	}
	public ObservableList<Module> getSelectedTerm2Contents() {
		return 	SelectedTerm2Text;
	}
	
	public ListView<Module> getSelectedYearLongList() {
		return 	SelectedModulesList;
	}
	public ListView<Module> getUnselectedTerm1List() {
		return 	UnselectedTerm1Modules;
	}
	public ListView<Module> getUnselectedTerm2List() {
		return 	UnselectedTerm2Modules;
	}
	public ListView<Module> getSelectedTerm1List() {
		return 	SelectedTerm1ModulesList;
	}
	public ListView<Module> getSelectedTerm2List() {
		return 	SelectedTerm2ModulesList;
	}


	public int getTerm1Credits() {
		return Term1Credits;
	}
	public int getTerm2Credits() {
		return Term2Credits;
	}
	
	public void ResetCredit(int x,int y) {

		Term1Credits=x;
		Term2Credits=y;
		CurrentTerm1Credits.clear();
		CurrentTerm1Credits.setText(String.valueOf(Term1Credits));
		CurrentTerm2Credits.clear();
		CurrentTerm2Credits.setText(String.valueOf(Term2Credits));
	}
	public void addterm1credits(int x) {

		Term1Credits=Term1Credits+x;
		CurrentTerm1Credits.clear();
		CurrentTerm1Credits.setText(String.valueOf(Term1Credits));
	}
	public void addterm2credits(int x) {

		Term2Credits=Term2Credits+x;
		CurrentTerm2Credits.clear();
		CurrentTerm2Credits.setText(String.valueOf(Term2Credits));
	}
	public void addAddSelectModulePage(EventHandler<ActionEvent> handler) {
		btnAdd.setOnAction(handler);
	}
	public void addRemoveSelectModulePage(EventHandler<ActionEvent> handler) {
		btnRemove.setOnAction(handler);
	}
	public void addAdd2SelectModulePage(EventHandler<ActionEvent> handler) {
		btnAdd2.setOnAction(handler);
	}
	public void addRemove2SelectModulePage(EventHandler<ActionEvent> handler) {
		btnRemove2.setOnAction(handler);
	}
	public void addResetSelectModulePage(EventHandler<ActionEvent> handler) {

		btnReset.setOnAction(handler);
	}
	public void addSubmitSelectModulePage(EventHandler<ActionEvent> handler) {
		btnSubmit.setOnAction(handler);
	}

	public void PopulateUnselectedTerm1List(Collection<Module> x) {
		UnselectedTerm1Text.setAll(x);
	}
	public void PopulateUnselectedTerm2List(Collection<Module> x) {
		UnselectedTerm2Text.setAll(x);
	}
	public void PopulateSelectedTerm1List(Collection<Module> x) {
		SelectedTerm1Text.setAll(x);
	}
	public void PopulateSelectedTerm2List(Collection<Module> x) {
		SelectedTerm2Text.setAll(x);
	}
	public void PopulateSelectedYearLongList(Collection<Module> x) {
		SelectedYearLongText.setAll(x);
	}	

}
