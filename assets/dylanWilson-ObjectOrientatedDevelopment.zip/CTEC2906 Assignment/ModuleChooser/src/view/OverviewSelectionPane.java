package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;

public class OverviewSelectionPane extends GridPane {
	private GridPane sarm;
	private TextArea SelectedView, ReservedView,profileView;
	private Button btnSave;
	private HBox buttons;
	private String profileViewText,SelectedViewText,ReservedViewText;

	public OverviewSelectionPane() {
		//styling
		this.setVgap(40);
		this.setAlignment(Pos.CENTER);
		this.setPadding(new Insets(40,40,40,40));

		ColumnConstraints column0 = new ColumnConstraints();
		column0.setHalignment(HPos.RIGHT);
		this.getColumnConstraints().addAll(column0);
		
		btnSave = new Button("Save Overview");
		btnSave.setPrefSize(100, 15);;
		
		buttons = new HBox();
		buttons.setAlignment(Pos.CENTER);
		buttons.getChildren().addAll(btnSave);
		
		
		profileViewText=("Profile will appear here");
		SelectedViewText=("Selected modules will appear here");
		ReservedViewText=("Reserved modules will appear here");
		
		
		profileView = new TextArea(profileViewText);
		profileView.setPrefSize(820, 150);
		profileView.setEditable(false);
		
		SelectedView=new TextArea(SelectedViewText);
		ReservedView=new TextArea(ReservedViewText);
		SelectedView.setEditable(false);
		ReservedView.setEditable(false);
		
		SelectedView.setPrefSize(400, 300);
		ReservedView.setPrefSize(400, 300);
		
		sarm = new GridPane();
		sarm.setVgap(15);
		sarm.setHgap(20);
		sarm.setAlignment(Pos.CENTER);
		
		ColumnConstraints column1 = new ColumnConstraints();
		column1.setHalignment(HPos.CENTER);
		sarm.getColumnConstraints().addAll(column1);
		sarm.add(SelectedView, 0, 0);
		sarm.add(ReservedView, 1, 0);
		GridPane.setHgrow(sarm, Priority.ALWAYS);
		GridPane.setVgrow(sarm, Priority.ALWAYS);
		GridPane.setHgrow(profileView, Priority.ALWAYS);
		GridPane.setHgrow(SelectedView, Priority.ALWAYS);
		GridPane.setHgrow(ReservedView, Priority.ALWAYS);
		GridPane.setVgrow(SelectedView, Priority.ALWAYS);
		GridPane.setVgrow(ReservedView, Priority.ALWAYS);	
		this.add(profileView, 0, 0);
		this.add(sarm,0,1);
		this.add(buttons, 0, 2);
		
	}
	public void populateProfileView(String profileString) {
		profileViewText=profileString;
		profileView.clear();
		profileView.setText(profileViewText);
	}
	public void populateSelectView(String SelectString) {
		SelectedViewText=SelectString;
		SelectedView.clear();
		SelectedView.setText(SelectedViewText);
	}
	public void populateReserveView(String ReserveString) {
		ReservedViewText=ReserveString;
		ReservedView.clear();
		ReservedView.setText(ReservedViewText);
		
	}
	public String getProfileViewText() {
		return profileViewText;
	}
	public String getSelectedViewText() {
		return SelectedViewText;
	}
	public String getReservedViewText() {
		return ReservedViewText;
	}
	public void addSaveOverviewSelectionPage(EventHandler<ActionEvent> handler) {
		btnSave.setOnAction(handler);
	}
}
