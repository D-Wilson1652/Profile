clc
warning('off','fuzzy:general:warnDeprecation_Newfis') 
warning('off','fuzzy:general:warnDeprecation_Addvar')
warning('off','fuzzy:general:warnDeprecation_Addmf')
warning('off','fuzzy:general:warnDeprecation_Evalfis')

a=newfis('Climbers Skill','DefuzzificationMethod','centroid');

a=addvar(a,'input','BMI',[12 40]);
% Populating the 1st input variable with membership functions
a = addmf(a, 'input', 1, 'Very Low', 'trapmf', [12 12 15 18]);
a = addmf(a, 'input', 1, 'Low', 'trimf', [15 18 21]);
a = addmf(a, 'input', 1, 'Average', 'trimf', [18 21 24 ]);
a = addmf(a, 'input', 1, 'High', 'trimf', [23 27 32]);
a = addmf(a, 'input', 1, 'Very High', 'trapmf', [29 33 40 40]);

a=addvar(a,'input','Experience',[0 20]);
% Populating the 2st input variable with membership functions
a = addmf(a, 'input', 2, 'Very Inexperienced', 'trapmf', [0 0 1 2]);
a = addmf(a, 'input', 2, 'Inexperienced', 'trimf', [1 3 5]);
a = addmf(a, 'input', 2, 'Average', 'trimf', [4 7 9 ]);
a = addmf(a, 'input', 2, 'Experienced', 'trimf', [7 10 13]);
a = addmf(a, 'input', 2, 'Very Experienced', 'trapmf', [10 15 20 20]);

a=addvar(a,'input','Strength',[0 50]);
% Populating the 3st input variable with membership functions
a = addmf(a, 'input', 3, 'Very Weak', 'trapmf', [0 0 1 3]);
a = addmf(a, 'input', 3, 'Weak', 'trimf', [2 4 6]);
a = addmf(a, 'input', 3, 'Average', 'trimf', [5 7 13 ]);
a = addmf(a, 'input', 3, 'Strong', 'trimf', [10 15 23 ]);
a = addmf(a, 'input', 3, 'Very Strong', 'trapmf', [18 30 50 50]);

a=addvar(a,'input','Ape Index',[-10 10]);
% Populating the 4st input variable with membership functions
a = addmf(a, 'input', 4, 'Very Small', 'trapmf', [-10 -10 -8 -5]);
a = addmf(a, 'input', 4, 'Small', 'trimf', [-7 -4  -2]);
a = addmf(a, 'input', 4, 'Average', 'trimf', [-3 0 3]);
a = addmf(a, 'input', 4, 'Long', 'trimf', [2 4 6]);
a = addmf(a, 'input', 4, 'Very Long', 'trapmf', [3 8 10 10]);

a=addvar (a,'output','Climbers Skill',[0 100]);
% Populating the 1st output variable with membership functions
a = addmf(a, 'output', 1, 'Very Low', 'trapmf', [0 0 10 20]);
a = addmf(a, 'output', 1, 'Low', 'trimf', [15 25 40]);
a = addmf(a, 'output', 1, 'Average', 'trimf', [30 50 70]);
a = addmf(a, 'output', 1, 'High', 'trimf', [60 70 80]);
a = addmf(a, 'output', 1, 'Very High', 'trapmf', [80 90 100 100]);

b=newfis('Difficulty of Wall','DefuzzificationMethod','centroid');

b=addvar(b,'input',' Wall Height',[0 4.5]);
% Populating the 1st input variable with membership functions
b = addmf(b, 'input', 1, 'Very Small', 'trapmf', [0 0 1 1.5]);
b = addmf(b, 'input', 1, 'Small', 'trimf', [1.25 1.75 2.5]);
b = addmf(b, 'input', 1, 'Average', 'trimf', [2.25 2.75 3.25 ]);
b = addmf(b, 'input', 1, 'Tall', 'trimf', [3 3.5 4]);
b = addmf(b, 'input', 1, 'Very Tall', 'trapmf', [3.75 4 4.5 4.5]);

b=addvar(b,'input','Hold Distance',[0 300]);
% Populating the 2st input variable with membership functions
b = addmf(b, 'input', 2, 'Very Small', 'trapmf', [0 0 60 120]);
b = addmf(b, 'input', 2, 'Small', 'trimf', [60 130 150]);
b = addmf(b, 'input', 2, 'Average', 'trimf', [145 170 195 ]);
b = addmf(b, 'input', 2, 'Tall', 'trimf', [180 200 220]);
b = addmf(b, 'input', 2, 'Very Tall', 'trapmf', [210 250 300 300]);

b=addvar(b,'input','Incline',[-90 90]);
% Populating the 3st input variable with membership functions
b = addmf(b, 'input', 3, 'Flat', 'trapmf', [-90 -90 -75 -50 ]);
b = addmf(b, 'input', 3, 'Inclined', 'trimf', [-60 -45 -10]);
b = addmf(b, 'input', 3, 'Straight', 'trimf', [-30 0 30 ]);
b = addmf(b, 'input', 3, 'Very Inclined', 'trimf', [10 45 70]);
b = addmf(b, 'input', 3, 'Overhang', 'trapmf', [60 75 90 90]);


b=addvar (b,'output','Wall Difficulty',[0 100]);
% Populating the 1st output variable with membership functions
b = addmf(b, 'output', 1, 'Very Low', 'trapmf', [0 0 10 20]);
b = addmf(b, 'output', 1, 'Low', 'trimf', [15 25 40]);
b = addmf(b, 'output', 1, 'Average', 'trimf', [30 50 70]);
b = addmf(b, 'output', 1, 'High', 'trimf', [60 70 80]);
b = addmf(b, 'output', 1, 'Very High', 'trapmf', [75 90 100 100]);

c=newfis('Success of climber','DefuzzificationMethod','centroid');

c=addvar(c,'input','Climbers Skill',[0 100]);
% Populating the 1st output variable with membership functions
c = addmf(c, 'input', 1, 'Very Low', 'trapmf', [0 0 10 20]);
c = addmf(c, 'input', 1, 'Low', 'trimf', [15 25 40]);
c = addmf(c, 'input', 1, 'Average', 'trimf', [30 50 70]);
c = addmf(c, 'input', 1, 'High', 'trimf', [60 70 80]);
c = addmf(c, 'input', 1, 'Very High', 'trapmf', [80 90 100 100]);

c=addvar(c,'input','Wall Difficulty',[0 100]);
% Populating the 2st output variable with membership functions
c = addmf(c, 'input', 2, 'Very Low', 'trapmf', [0 0 10 20]);
c = addmf(c, 'input', 2, 'Low', 'trimf', [15 25 40]);
c = addmf(c, 'input', 2, 'Average', 'trimf', [30 50 70]);
c = addmf(c, 'input', 2, 'High', 'trimf', [60 70 80]);
c = addmf(c, 'input', 2, 'Very High', 'trapmf', [80 90 100 100])

c=addvar(c,'output','Success of climber',[0 100]);
% Populating the 3st output variable with membership functions
c = addmf(c, 'output', 1, 'Very Small', 'trapmf', [0 0 10 20]);
c = addmf(c, 'output', 1, 'Small', 'trimf', [15 25 40]);
c = addmf(c, 'output', 1, 'Moderate', 'trimf', [30 50 70]);
c = addmf(c, 'output', 1, 'High', 'trimf', [60 70 80]);
c = addmf(c, 'output', 1, 'Very High', 'trapmf', [80 90 100 100]);

subplot(5,1,1), plotmf(a,'input',1)
subplot(5,1,2), plotmf(a,'input',2)
subplot(5,1,3), plotmf(a,'input',3)
subplot(5,1,4), plotmf(a,'input',4)
subplot(5,1,5), plotmf(a,'output',1)
% all cases in a that end in a very low result
rule1 = [1 1 1 1 1 1 1];
rule2 = [1 2 1 1 1 1 1];
rule3 = [1 1 2 1 1 1 1];
rule4 = [1 1 1 2 1 1 1];
rule5 = [1 2 1 2 2 1 1];
rule6 = [1 1 2 2 2 1 1];
rule7=  [1 2 2 1 2 1 1];
rule8=  [1 3 1 1 2 1 1];
rule9=  [1 1 3 1 2 1 1];
rule10= [1 1 1 3 2 1 1];
rule11= [1 3 1 3 3 1 1];
rule12= [1 1 3 3 3 1 1];
rule13= [1 3 3 1 3 1 1];
rule14= [1 4 1 1 2 1 1];
rule15= [1 1 4 1 2 1 1];
rule16= [1 1 1 4 2 1 1];
rule17= [1 4 4 1 3 1 1];
rule18= [1 1 4 4 3 1 1];
rule19= [1 4 1 4 3 1 1];
rule20= [1 5 1 1 3 1 1];
rule21= [1 1 5 1 3 1 1];
rule22= [1 1 1 5 3 1 1];
rule23= [1 5 1 5 3 1 1];
rule24= [1 1 5 5 3 1 1];
rule25= [1 5 5 1 3 1 1];
rule26= [1 2 2 2 2 1 1];
rule27= [1 3 2 2 2 1 1];
rule28= [1 2 3 2 2 1 1];
rule29= [1 2 2 3 2 1 1];
rule30= [1 3 2 3 3 1 1];
rule31= [1 3 3 2 3 1 1];
rule32= [1 2 3 3 3 1 1];
rule33= [1 4 2 2 3 1 1];
rule34= [1 2 4 2 3 1 1];
rule35= [1 2 2 4 3 1 1];
rule36= [1 4 2 4 3 1 1];
rule37= [1 4 4 2 3 1 1];
rule38= [1 2 4 2 3 1 1];
rule39= [1 5 2 2 3 1 1];
rule40= [1 2 5 2 3 1 1];
rule41= [1 2 2 5 3 1 1];
rule42= [1 5 2 5 3 1 1];
rule43= [1 2 5 5 3 1 1];
rule44= [1 5 5 2 3 1 1];
rule45= [1 3 3 3 3 1 1];
rule46= [1 4 3 3 3 1 1];
rule47= [1 3 4 3 3 1 1];
rule48= [1 3 3 4 3 1 1];
rule49= [1 4 3 4 3 1 1];
rule50= [1 4 4 3 3 1 1];
rule51= [1 3 4 4 3 1 1];
rule52= [1 5 3 3 3 1 1];
rule53= [1 3 5 3 3 1 1];
rule54= [1 3 3 5 3 1 1];
rule55= [1 5 3 5 4 1 1];
rule56= [1 5 5 3 4 1 1];
rule57= [1 3 5 5 4 1 1];
rule58= [1 4 4 4 4 1 1];
rule59= [1 5 4 4 4 1 1];
rule60= [1 4 5 4 4 1 1];
rule61= [1 4 4 5 4 1 1];
rule62= [1 5 5 4 4 1 1];
rule63= [1 5 4 5 4 1 1];
rule64= [1 4 5 5 4 1 1];
rule65= [1 5 5 5 4 1 1];
rule66= [1 1 2 3 2 1 1];
rule67= [1 2 1 3 2 1 1];
rule68= [1 1 3 2 2 1 1];
rule69= [1 2 3 1 2 1 1];
rule70= [1 3 1 2 2 1 1];
rule71= [1 3 2 1 2 1 1];
rule72= [1 2 3 4 3 1 1];
rule73= [1 3 2 4 3 1 1];
rule74= [1 2 4 3 3 1 1];
rule75= [1 3 4 2 3 1 1];
rule76= [1 4 2 3 3 1 1];
rule77= [1 4 3 2 3 1 1];
rule78= [1 3 4 5 4 1 1];
rule79= [1 4 3 5 3 1 1];
rule80= [1 3 5 4 3 1 1];
rule81= [1 4 5 3 3 1 1];
rule82= [1 5 3 4 3 1 1];
rule83= [1 5 4 3 3 1 1];
rule84= [1 1 2 4 2 1 1];
rule85= [1 2 1 4 2 1 1];
rule86= [1 1 4 2 2 1 1];
rule87= [1 2 4 1 2 1 1];
rule88= [1 4 1 2 2 1 1];
rule89= [1 4 2 1 2 1 1];
rule90= [1 1 2 5 3 1 1];
rule91= [1 2 1 5 3 1 1];
rule92= [1 1 5 2 3 1 1];
rule93= [1 2 5 1 3 1 1];
rule94= [1 5 1 2 3 1 1];
rule95= [1 5 2 1 3 1 1];
rule96= [1 2 3 5 3 1 1];
rule97= [1 3 2 5 3 1 1];
rule98= [1 2 5 3 3 1 1];
rule99= [1 3 5 2 3 1 1];
rule100= [1 5 2 3 3 1 1];
rule101= [1 5 3 2 3 1 1];
rule102= [1 1 3 5 3 1 1];
rule103= [1 3 1 5 3 1 1];
rule104= [1 1 5 3 3 1 1];
rule105= [1 3 5 1 3 1 1];
rule106= [1 5 1 3 3 1 1];
rule107= [1 5 3 1 3 1 1];
rule108= [1 1 4 5 3 1 1];
rule109= [1 4 1 5 3 1 1];
rule110= [1 1 5 4 3 1 1];
rule111= [1 4 5 1 3 1 1];
rule112= [1 5 1 4 3 1 1];
rule113= [1 5 4 1 3 1 1];
rule114= [1 2 4 5 3 1 1];
rule115= [1 4 2 5 3 1 1];
rule116= [1 2 5 4 3 1 1];
rule117= [1 4 5 2 3 1 1];
rule118= [1 5 2 4 3 1 1];
rule119= [1 5 4 2 3 1 1];
rule120= [1 1 3 4 3 1 1];
rule121= [1 1 4 3 3 1 1];
rule122= [1 4 1 3 3 1 1];
rule123= [1 3 1 4 3 1 1];
rule124= [1 4 3 1 3 1 1];
rule125= [1 3 4 1 3 1 1];
rule126= [2 1 1 1 1 1 1];
rule127= [2 2 1 1 1 1 1];
rule128= [2 1 2 1 1 1 1];
rule129= [2 1 1 2 1 1 1];
rule130= [2 2 1 2 2 1 1];
rule131= [2 1 2 2 2 1 1];
rule132= [2 2 2 1 2 1 1];
rule133= [2 3 1 1 2 1 1];
rule134= [2 1 3 1 2 1 1];
rule135= [2 1 1 3 2 1 1];
rule136= [2 3 1 3 3 1 1];
rule137= [2 1 3 3 3 1 1];
rule138= [2 3 3 1 3 1 1];
rule139= [2 4 1 1 2 1 1];
rule140= [2 1 4 1 2 1 1];
rule141= [2 1 1 4 2 1 1];
rule142= [2 4 4 1 4 1 1];
rule143= [2 1 4 4 4 1 1];
rule144= [2 4 1 4 4 1 1];
rule145= [2 5 1 1 3 1 1];
rule146= [2 1 5 1 3 1 1];
rule147= [2 1 1 5 3 1 1];
rule148= [2 5 1 5 4 1 1];
rule149= [2 1 5 5 4 1 1];
rule150= [2 5 5 1 4 1 1];
rule151= [2 2 2 2 2 1 1];
rule152= [2 3 2 2 2 1 1];
rule153= [2 2 3 2 2 1 1];
rule154= [2 2 2 3 2 1 1];
rule155= [2 3 2 3 3 1 1];
rule156= [2 3 3 2 3 1 1];
rule157= [2 2 3 3 3 1 1];
rule158= [2 4 2 2 3 1 1];
rule159= [2 2 4 2 3 1 1];
rule160= [2 2 2 4 3 1 1];
rule161= [2 4 2 4 4 1 1];
rule162= [2 4 4 2 4 1 1];
rule163= [2 2 4 2 4 1 1];
rule164= [2 5 2 2 3 1 1];
rule165= [2 2 5 2 3 1 1];
rule166= [2 2 2 5 3 1 1];
rule167= [2 5 2 5 4 1 1];
rule168= [2 2 5 5 4 1 1];
rule169= [2 5 5 2 4 1 1];
rule170= [2 3 3 3 3 1 1];
rule171= [2 4 3 3 3 1 1];
rule172= [2 3 4 3 3 1 1];
rule173= [2 3 3 4 3 1 1];
rule174= [2 4 3 4 4 1 1];
rule175= [2 4 4 3 4 1 1];
rule176= [2 3 4 4 4 1 1];
rule177= [2 5 3 3 3 1 1];
rule178= [2 3 5 3 3 1 1];
rule179= [2 3 3 5 3 1 1];
rule180= [2 5 3 5 5 1 1];
rule181= [2 5 5 3 5 1 1];
rule182= [2 3 5 5 5 1 1];
rule183= [2 4 4 4 4 1 1];
rule184= [2 5 4 4 4 1 1];
rule185= [2 4 5 4 4 1 1];
rule186= [2 4 4 5 4 1 1];
rule187= [2 5 5 4 5 1 1];
rule188= [2 5 4 5 5 1 1];
rule189= [2 4 5 5 5 1 1];
rule190= [2 5 5 5 5 1 1];
rule191= [2 1 2 3 2 1 1];
rule192= [2 2 1 3 2 1 1];
rule193= [2 1 3 2 2 1 1];
rule194= [2 2 3 1 2 1 1];
rule195= [2 3 1 2 2 1 1];
rule196= [2 3 2 1 2 1 1];
rule197= [2 2 3 4 3 1 1];
rule198= [2 3 2 4 3 1 1];
rule199= [2 2 4 3 3 1 1];
rule200= [2 3 4 2 3 1 1];
rule201= [2 4 2 3 3 1 1];
rule202= [2 4 3 2 3 1 1];
rule203= [2 3 4 5 4 1 1];
rule204= [2 4 3 5 4 1 1];
rule205= [2 3 5 4 4 1 1];
rule206= [2 4 5 3 4 1 1];
rule207= [2 5 3 4 4 1 1];
rule208= [2 5 4 3 4 1 1];
rule209= [2 1 2 4 2 1 1];
rule210= [2 2 1 4 2 1 1];
rule211= [2 1 4 2 2 1 1];
rule212= [2 2 4 1 2 1 1];
rule213= [2 4 1 2 2 1 1];
rule214= [2 4 2 1 2 1 1];
rule215= [2 1 2 5 3 1 1];
rule216= [2 2 1 5 3 1 1];
rule217= [2 1 5 2 3 1 1];
rule218= [2 2 5 1 3 1 1];
rule219= [2 5 1 2 3 1 1];
rule220= [2 5 2 1 3 1 1];
rule221= [2 2 3 5 4 1 1];
rule222= [2 3 2 5 4 1 1];
rule223= [2 2 5 3 4 1 1];
rule224= [2 3 5 2 4 1 1];
rule225= [2 5 2 3 4 1 1];
rule226= [2 5 3 2 4 1 1];
rule227= [2 1 3 5 3 1 1];
rule228= [2 3 1 5 3 1 1];
rule229= [2 1 5 3 3 1 1];
rule230= [2 3 5 1 3 1 1];
rule231= [2 5 1 3 3 1 1];
rule232= [2 5 3 1 3 1 1];
rule233= [2 1 4 5 3 1 1];
rule234= [2 4 1 5 3 1 1];
rule235= [2 1 5 4 3 1 1];
rule236= [2 4 5 1 3 1 1];
rule237= [2 5 1 4 3 1 1];
rule238= [2 5 4 1 3 1 1];
rule239= [2 2 4 5 4 1 1];
rule240= [2 4 2 5 4 1 1];
rule241= [2 2 5 4 4 1 1];
rule242= [2 4 5 2 4 1 1];
rule243= [2 5 2 4 4 1 1];
rule244= [2 5 4 2 4 1 1];
rule245= [2 1 3 4 3 1 1];
rule246= [2 1 4 3 3 1 1];
rule247= [2 4 1 3 3 1 1];
rule248= [2 3 1 4 3 1 1];
rule249= [2 4 3 1 3 1 1];
rule250= [2 3 4 1 3 1 1];
rule251= [3 1 1 1 1 1 1];
rule252= [3 2 1 1 1 1 1];
rule253= [3 1 2 1 1 1 1];
rule254= [3 1 1 2 1 1 1];
rule255= [3 2 1 2 2 1 1];
rule256= [3 1 2 2 2 1 1];
rule257= [3 2 2 1 2 1 1];
rule258= [3 3 1 1 2 1 1];
rule259= [3 1 3 1 2 1 1];
rule260= [3 1 1 3 2 1 1];
rule261= [3 3 1 3 3 1 1];
rule262= [3 1 3 3 3 1 1];
rule263= [3 3 3 1 3 1 1];
rule264= [3 4 1 1 2 1 1];
rule265= [3 1 4 1 2 1 1];
rule266= [3 1 1 4 2 1 1];
rule267= [3 4 4 1 4 1 1];
rule268= [3 1 4 4 4 1 1];
rule269= [3 4 1 4 4 1 1];
rule270= [3 5 1 1 3 1 1];
rule271= [3 1 5 1 3 1 1];
rule272= [3 1 1 5 3 1 1];
rule273= [3 5 1 5 4 1 1];
rule274= [3 1 5 5 4 1 1];
rule275= [3 5 5 1 4 1 1];
rule276= [3 2 2 2 2 1 1];
rule277= [3 3 2 2 2 1 1];
rule278= [3 2 3 2 2 1 1];
rule279= [3 2 2 3 2 1 1];
rule280= [3 3 2 3 3 1 1];
rule281= [3 3 3 2 3 1 1];
rule282= [3 2 3 3 3 1 1];
rule283= [3 4 2 2 3 1 1];
rule284= [3 2 4 2 3 1 1];
rule285= [3 2 2 4 3 1 1];
rule286= [3 4 2 4 4 1 1];
rule287= [3 4 4 2 4 1 1];
rule288= [3 2 4 2 4 1 1];
rule289= [3 5 2 2 3 1 1];
rule290= [3 2 5 2 3 1 1];
rule291= [3 2 2 5 3 1 1];
rule292= [3 5 2 5 4 1 1];
rule293= [3 2 5 5 4 1 1];
rule294= [3 5 5 2 4 1 1];
rule295= [3 3 3 3 3 1 1];
rule296= [3 4 3 3 3 1 1];
rule297= [3 3 4 3 3 1 1];
rule298= [3 3 3 4 3 1 1];
rule299= [3 4 3 4 4 1 1];
rule300= [3 4 4 3 4 1 1];
rule301= [3 3 4 4 4 1 1];
rule302= [3 5 3 3 3 1 1];
rule303= [3 3 5 3 3 1 1];
rule304= [3 3 3 5 3 1 1];
rule305= [3 5 3 5 5 1 1];
rule306= [3 5 5 3 5 1 1];
rule307= [3 3 5 5 5 1 1];
rule308= [3 4 4 4 4 1 1];
rule309= [3 5 4 4 4 1 1];
rule310= [3 4 5 4 4 1 1];
rule311= [3 4 4 5 4 1 1];
rule312= [3 5 5 4 5 1 1];
rule313= [3 5 4 5 5 1 1];
rule314= [3 4 5 5 5 1 1];
rule315= [3 5 5 5 5 1 1];
rule316= [3 1 2 3 2 1 1];
rule317= [3 2 1 3 2 1 1];
rule318= [3 1 3 2 2 1 1];
rule319= [3 2 3 1 2 1 1];
rule320= [3 3 1 2 2 1 1];
rule321= [3 3 2 1 2 1 1];
rule322= [3 2 3 4 3 1 1];
rule323= [3 3 2 4 3 1 1];
rule324= [3 2 4 3 3 1 1];
rule325= [3 3 4 2 3 1 1];
rule326= [3 4 2 3 3 1 1];
rule327= [3 4 3 2 3 1 1];
rule328= [3 3 4 5 4 1 1];
rule329= [3 4 3 5 4 1 1];
rule330= [3 3 5 4 4 1 1];
rule331= [3 4 5 3 4 1 1];
rule332= [3 5 3 4 4 1 1];
rule333= [3 5 4 3 4 1 1];
rule334= [3 1 2 4 2 1 1];
rule335= [3 2 1 4 2 1 1];
rule336= [3 1 4 2 2 1 1];
rule337= [3 2 4 1 2 1 1];
rule338= [3 4 1 2 2 1 1];
rule339= [3 4 2 1 2 1 1];
rule340= [3 1 2 5 3 1 1];
rule341= [3 2 1 5 3 1 1];
rule342= [3 1 5 2 3 1 1];
rule343= [3 2 5 1 3 1 1];
rule344= [3 5 1 2 3 1 1];
rule345= [3 5 2 1 3 1 1];
rule346= [3 2 3 5 4 1 1];
rule347= [3 3 2 5 4 1 1];
rule348= [3 2 5 3 4 1 1];
rule349= [3 3 5 2 4 1 1];
rule350= [3 5 2 3 4 1 1];
rule351= [3 5 3 2 4 1 1];
rule352= [3 1 3 5 3 1 1];
rule353= [3 3 1 5 3 1 1];
rule354= [3 1 5 3 3 1 1];
rule355= [3 3 5 1 3 1 1];
rule356= [3 5 1 3 3 1 1];
rule357= [3 5 3 1 3 1 1];
rule358= [3 1 4 5 3 1 1];
rule359= [3 4 1 5 3 1 1];
rule360= [3 1 5 4 3 1 1];
rule361= [3 4 5 1 3 1 1];
rule362= [3 5 1 4 3 1 1];
rule363= [3 5 4 1 3 1 1];
rule364= [3 2 4 5 4 1 1];
rule365= [3 4 2 5 4 1 1];
rule366= [3 2 5 4 4 1 1];
rule367= [3 4 5 2 4 1 1];
rule368= [3 5 2 4 4 1 1];
rule369= [3 5 4 2 4 1 1];
rule370= [3 1 3 4 3 1 1];
rule371= [3 1 4 3 3 1 1];
rule372= [3 4 1 3 3 1 1];
rule373= [3 3 1 4 3 1 1];
rule374= [3 4 3 1 3 1 1];
rule375= [3 3 4 1 3 1 1];
rule376= [4 1 1 1 1 1 1];
rule377= [4 2 1 1 1 1 1];
rule378= [4 1 2 1 1 1 1];
rule379= [4 1 1 2 1 1 1];
rule380= [4 2 1 2 2 1 1];
rule381= [4 1 2 2 2 1 1];
rule382= [4 2 2 1 2 1 1];
rule383= [4 3 1 1 2 1 1];
rule384= [4 1 3 1 2 1 1];
rule385= [4 1 1 3 2 1 1];
rule386= [4 3 1 3 3 1 1];
rule387= [4 1 3 3 3 1 1];
rule388= [4 3 3 1 3 1 1];
rule389= [4 4 1 1 2 1 1];
rule390= [4 1 4 1 2 1 1];
rule391= [4 1 1 4 2 1 1];
rule392= [4 4 4 1 4 1 1];
rule393= [4 1 4 4 4 1 1];
rule394= [4 4 1 4 4 1 1];
rule395= [4 5 1 1 3 1 1];
rule396= [4 1 5 1 3 1 1];
rule397= [4 1 1 5 3 1 1];
rule398= [4 5 1 5 4 1 1];
rule399= [4 1 5 5 4 1 1];
rule400= [4 5 5 1 4 1 1];
rule401= [4 2 2 2 2 1 1];
rule402= [4 3 2 2 2 1 1];
rule403= [4 2 3 2 2 1 1];
rule404= [4 2 2 3 2 1 1];
rule405= [4 3 2 3 3 1 1];
rule406= [4 3 3 2 3 1 1];
rule407= [4 2 3 3 3 1 1];
rule408= [4 4 2 2 3 1 1];
rule409= [4 2 4 2 3 1 1];
rule410= [4 2 2 4 3 1 1];
rule411= [4 4 2 4 4 1 1];
rule412= [4 4 4 2 4 1 1];
rule413= [4 2 4 2 4 1 1];
rule414= [4 5 2 2 3 1 1];
rule415= [4 2 5 2 3 1 1];
rule416= [4 2 2 5 3 1 1];
rule417= [4 5 2 5 4 1 1];
rule418= [4 2 5 5 4 1 1];
rule419= [4 5 5 2 4 1 1];
rule420= [4 3 3 3 3 1 1];
rule421= [4 4 3 3 3 1 1];
rule422= [4 3 4 3 3 1 1];
rule423= [4 3 3 4 3 1 1];
rule424= [4 4 3 4 4 1 1];
rule425= [4 4 4 3 4 1 1];
rule426= [4 3 4 4 4 1 1];
rule427= [4 5 3 3 3 1 1];
rule428= [4 3 5 3 3 1 1];
rule429= [4 3 3 5 3 1 1];
rule430= [4 5 3 5 5 1 1];
rule431= [4 5 5 3 5 1 1];
rule432= [4 3 5 5 5 1 1];
rule433= [4 4 4 4 4 1 1];
rule434= [4 5 4 4 4 1 1];
rule435= [4 4 5 4 4 1 1];
rule436= [4 4 4 5 4 1 1];
rule437= [4 5 5 4 5 1 1];
rule438= [4 5 4 5 5 1 1];
rule439= [4 4 5 5 5 1 1];
rule440= [4 5 5 5 5 1 1];
rule441= [4 1 2 3 2 1 1];
rule442= [4 2 1 3 2 1 1];
rule443= [4 1 3 2 2 1 1];
rule444= [4 2 3 1 2 1 1];
rule445= [4 3 1 2 2 1 1];
rule446= [4 3 2 1 2 1 1];
rule447= [4 2 3 4 3 1 1];
rule448= [4 3 2 4 3 1 1];
rule449= [4 2 4 3 3 1 1];
rule450= [4 3 4 2 3 1 1];
rule451= [4 4 2 3 3 1 1];
rule452= [4 4 3 2 3 1 1];
rule453= [4 3 4 5 4 1 1];
rule454= [4 4 3 5 4 1 1];
rule455= [4 3 5 4 4 1 1];
rule456= [4 4 5 3 4 1 1];
rule457= [4 5 3 4 4 1 1];
rule458= [4 5 4 3 4 1 1];
rule459= [4 1 2 4 2 1 1];
rule460= [4 2 1 4 2 1 1];
rule461= [4 1 4 2 2 1 1];
rule462= [4 2 4 1 2 1 1];
rule463= [4 4 1 2 2 1 1];
rule464= [4 4 2 1 2 1 1];
rule465= [4 1 2 5 3 1 1];
rule466= [4 2 1 5 3 1 1];
rule467= [4 1 5 2 3 1 1];
rule468= [4 2 5 1 3 1 1];
rule469= [4 5 1 2 3 1 1];
rule470= [4 5 2 1 3 1 1];
rule471= [4 2 3 5 4 1 1];
rule472= [4 3 2 5 4 1 1];
rule473= [4 2 5 3 4 1 1];
rule474= [4 3 5 2 4 1 1];
rule475= [4 5 2 3 4 1 1];
rule476= [4 5 3 2 4 1 1];
rule477= [4 1 3 5 3 1 1];
rule478= [4 3 1 5 3 1 1];
rule479= [4 1 5 3 3 1 1];
rule480= [4 3 5 1 3 1 1];
rule481= [4 5 1 3 3 1 1];
rule482= [4 5 3 1 3 1 1];
rule483= [4 1 4 5 3 1 1];
rule484= [4 4 1 5 3 1 1];
rule485= [4 1 5 4 3 1 1];
rule486= [4 4 5 1 3 1 1];
rule487= [4 5 1 4 3 1 1];
rule488= [4 5 4 1 3 1 1];
rule489= [4 2 4 5 4 1 1];
rule490= [4 4 2 5 4 1 1];
rule491= [4 2 5 4 4 1 1];
rule492= [4 4 5 2 4 1 1];
rule493= [4 5 2 4 4 1 1];
rule494= [4 5 4 2 4 1 1];
rule495= [4 1 3 4 3 1 1];
rule496= [4 1 4 3 3 1 1];
rule497= [4 4 1 3 3 1 1];
rule498= [4 3 1 4 3 1 1];
rule499= [4 4 3 1 3 1 1];
rule500= [4 3 4 1 3 1 1];
rule501= [5 1 1 1 2 1 1];
rule502= [5 2 1 1 2 1 1];
rule503= [5 1 2 1 2 1 1];
rule504= [5 1 1 2 2 1 1];
rule505= [5 2 1 2 2 1 1];
rule506= [5 1 2 2 2 1 1];
rule507= [5 2 2 1 2 1 1];
rule508= [5 3 1 1 2 1 1];
rule509= [5 1 3 1 2 1 1];
rule510= [5 1 1 3 2 1 1];
rule511= [5 3 1 3 3 1 1];
rule512= [5 1 3 3 3 1 1];
rule513= [5 3 3 1 3 1 1];
rule514= [5 4 1 1 2 1 1];
rule515= [5 1 4 1 2 1 1];
rule516= [5 1 1 4 2 1 1];
rule517= [5 4 4 1 4 1 1];
rule518= [5 1 4 4 4 1 1];
rule519= [5 4 1 4 4 1 1];
rule520= [5 5 1 1 3 1 1];
rule521= [5 1 5 1 3 1 1];
rule522= [5 1 1 5 3 1 1];
rule523= [5 5 1 5 4 1 1];
rule524= [5 1 5 5 4 1 1];
rule525= [5 5 5 1 4 1 1];
rule526= [5 2 2 2 2 1 1];
rule527= [5 3 2 2 2 1 1];
rule528= [5 2 3 2 2 1 1];
rule529= [5 2 2 3 2 1 1];
rule530= [5 3 2 3 3 1 1];
rule531= [5 3 3 2 3 1 1];
rule532= [5 2 3 3 3 1 1];
rule533= [5 4 2 2 3 1 1];
rule534= [5 2 4 2 3 1 1];
rule535= [5 2 2 4 3 1 1];
rule536= [5 4 2 4 4 1 1];
rule537= [5 4 4 2 4 1 1];
rule538= [5 2 4 2 4 1 1];
rule539= [5 5 2 2 3 1 1];
rule540= [5 2 5 2 3 1 1];
rule541= [5 2 2 5 3 1 1];
rule542= [5 5 2 5 4 1 1];
rule543= [5 2 5 5 4 1 1];
rule544= [5 5 5 2 4 1 1];
rule545= [5 3 3 3 4 1 1];
rule546= [5 4 3 3 4 1 1];
rule547= [5 3 4 3 4 1 1];
rule548= [5 3 3 4 4 1 1];
rule549= [5 4 3 4 4 1 1];
rule550= [5 4 4 3 4 1 1];
rule551= [5 3 4 4 4 1 1];
rule552= [5 5 3 3 4 1 1];
rule553= [5 3 5 3 4 1 1];
rule554= [5 3 3 5 4 1 1];
rule555= [5 5 3 5 5 1 1];
rule556= [5 5 5 3 5 1 1];
rule557= [5 3 5 5 5 1 1];
rule558= [5 4 4 4 5 1 1];
rule559= [5 5 4 4 5 1 1];
rule560= [5 4 5 4 5 1 1];
rule561= [5 4 4 5 5 1 1];
rule562= [5 5 5 4 5 1 1];
rule563= [5 5 4 5 5 1 1];
rule564= [5 4 5 5 5 1 1];
rule565= [5 5 5 5 5 1 1];
rule566= [5 1 2 3 2 1 1];
rule567= [5 2 1 3 2 1 1];
rule568= [5 1 3 2 2 1 1];
rule569= [5 2 3 1 2 1 1];
rule570= [5 3 1 2 2 1 1];
rule571= [5 3 2 1 2 1 1];
rule572= [5 2 3 4 4 1 1];
rule573= [5 3 2 4 4 1 1];
rule574= [5 2 4 3 4 1 1];
rule575= [5 3 4 2 4 1 1];
rule576= [5 4 2 3 4 1 1];
rule577= [5 4 3 2 4 1 1];
rule578= [5 3 4 5 4 1 1];
rule579= [5 4 3 5 4 1 1];
rule580= [5 3 5 4 4 1 1];
rule581= [5 4 5 3 4 1 1];
rule582= [5 5 3 4 4 1 1];
rule583= [5 5 4 3 4 1 1];
rule584= [5 1 2 4 2 1 1];
rule585= [5 2 1 4 2 1 1];
rule586= [5 1 4 2 2 1 1];
rule587= [5 2 4 1 2 1 1];
rule588= [5 4 1 2 2 1 1];
rule589= [5 4 2 1 2 1 1];
rule590= [5 1 2 5 3 1 1];
rule591= [5 2 1 5 3 1 1];
rule592= [5 1 5 2 3 1 1];
rule593= [5 2 5 1 3 1 1];
rule594= [5 5 1 2 3 1 1];
rule595= [5 5 2 1 3 1 1];
rule596= [5 2 3 5 4 1 1];
rule597= [5 3 2 5 4 1 1];
rule598= [5 2 5 3 4 1 1];
rule599= [5 3 5 2 4 1 1];
rule600= [5 5 2 3 4 1 1];
rule601= [5 5 3 2 4 1 1];
rule602= [5 1 3 5 3 1 1];
rule603= [5 3 1 5 3 1 1];
rule604= [5 1 5 3 3 1 1];
rule605= [5 3 5 1 3 1 1];
rule606= [5 5 1 3 3 1 1];
rule607= [5 5 3 1 3 1 1];
rule608= [5 1 4 5 3 1 1];
rule609= [5 4 1 5 3 1 1];
rule610= [5 1 5 4 3 1 1];
rule611= [5 4 5 1 3 1 1];
rule612= [5 5 1 4 3 1 1];
rule613= [5 5 4 1 3 1 1];
rule614= [5 2 4 5 4 1 1];
rule615= [5 4 2 5 4 1 1];
rule616= [5 2 5 4 4 1 1];
rule617= [5 4 5 2 4 1 1];
rule618= [5 5 2 4 4 1 1];
rule619= [5 5 4 2 4 1 1];
rule620= [5 1 3 4 4 1 1];
rule621= [5 1 4 3 4 1 1];
rule622= [5 4 1 3 4 1 1];
rule623= [5 3 1 4 4 1 1];
rule624= [5 4 3 1 4 1 1];
rule625= [5 3 4 1 4 1 1];





AruleList = [rule1;rule2;rule3;rule4;rule5;rule6;rule7;rule8;rule9;rule10;
    rule11;rule12;rule13;rule14;rule15;rule16;rule17;rule18;rule19;rule20;
    rule21;rule22;rule23;rule24;rule25;rule26;rule27;rule28;rule29;rule30;
    rule31;rule32;rule33;rule34;rule35;rule36;rule37;rule38;rule39;rule40;
    rule41;rule42;rule43;rule44;rule45;rule46;rule47;rule48;rule49;rule50;
    rule51;rule52;rule53;rule54;rule55;rule56;rule57;rule58;rule59;rule60;
    rule61;rule62;rule63;rule64;rule65;rule66;rule67;rule68;rule69;rule70;
    rule71;rule72;rule73;rule74;rule75;rule76;rule77;rule78;rule79;rule80;
    rule81;rule82;rule83;rule84;rule85;rule86;rule87;rule88;rule89;rule90;
    rule91;rule92;rule93;rule94;rule95;rule96;rule97;rule98;rule99;rule100;
    rule101;rule102;rule103;rule104;rule105;rule106;rule107;rule108;rule109;rule110;
    rule111;rule112;rule113;rule114;rule115;rule116;rule117;rule118;rule119;rule120;
    rule121;rule122;rule123;rule124;rule125;rule126;rule127;rule128;rule129;rule130;
    rule131;rule132;rule133;rule134;rule135;rule136;rule137;rule138;rule139;rule140;
    rule141;rule142;rule143;rule144;rule145;rule146;rule147;rule148;rule149;rule150;
    rule151;rule152;rule153;rule154;rule155;rule156;rule157;rule158;rule159;rule160;
    rule161;rule162;rule163;rule164;rule165;rule166;rule167;rule168;rule169;rule170;
    rule171;rule172;rule173;rule174;rule175;rule176;rule177;rule178;rule179;rule180;
    rule181;rule182;rule183;rule184;rule185;rule186;rule187;rule188;rule189;rule190;
    rule191;rule192;rule193;rule194;rule195;rule196;rule197;rule198;rule199;rule200;
    rule201;rule202;rule203;rule204;rule205;rule206;rule207;rule208;rule209;rule210;
    rule211;rule212;rule213;rule214;rule215;rule216;rule217;rule218;rule219;rule220;
    rule221;rule222;rule223;rule224;rule225;rule226;rule227;rule228;rule229;rule230;
    rule231;rule232;rule233;rule234;rule235;rule236;rule237;rule238;rule239;rule240;
    rule241;rule242;rule243;rule244;rule245;rule246;rule247;rule248;rule249;rule250;
    rule251;rule252;rule253;rule254;rule255;rule256;rule257;rule258;rule259;rule260;
    rule261;rule262;rule263;rule264;rule265;rule266;rule267;rule268;rule269;rule270;
    rule271;rule272;rule273;rule274;rule275;rule276;rule277;rule278;rule279;rule280;
    rule281;rule282;rule283;rule284;rule285;rule286;rule287;rule288;rule289;rule290;
    rule291;rule292;rule293;rule294;rule295;rule296;rule297;rule298;rule299;rule300;
    rule301;rule302;rule303;rule304;rule305;rule306;rule307;rule308;rule309;rule310;
    rule311;rule312;rule313;rule314;rule315;rule316;rule317;rule318;rule319;rule320;
    rule321;rule322;rule323;rule324;rule325;rule326;rule327;rule328;rule329;rule330;
    rule331;rule332;rule333;rule334;rule335;rule336;rule337;rule338;rule339;rule340;
    rule341;rule342;rule343;rule344;rule345;rule346;rule347;rule348;rule349;rule350;
    rule351;rule352;rule353;rule354;rule355;rule356;rule357;rule358;rule359;rule360;
    rule361;rule362;rule363;rule364;rule365;rule366;rule367;rule368;rule369;rule370;
    rule371;rule372;rule373;rule374;rule375;rule376;rule377;rule378;rule379;rule380;
    rule381;rule382;rule383;rule384;rule385;rule386;rule387;rule388;rule389;rule390;
    rule391;rule392;rule393;rule394;rule395;rule396;rule397;rule398;rule399;rule400;
    rule401;rule402;rule403;rule404;rule405;rule406;rule407;rule408;rule409;rule410;
    rule411;rule412;rule413;rule414;rule415;rule416;rule417;rule418;rule419;rule420;
    rule421;rule422;rule423;rule424;rule425;rule426;rule427;rule428;rule429;rule430;
    rule431;rule432;rule433;rule434;rule435;rule436;rule437;rule438;rule439;rule440;
    rule441;rule442;rule443;rule444;rule445;rule446;rule447;rule448;rule449;rule450;
    rule451;rule452;rule453;rule454;rule455;rule456;rule457;rule458;rule459;rule460;
    rule461;rule462;rule463;rule464;rule465;rule466;rule467;rule468;rule469;rule470;
    rule471;rule472;rule473;rule474;rule475;rule476;rule477;rule478;rule479;rule480;
    rule481;rule482;rule483;rule484;rule485;rule486;rule487;rule488;rule489;rule490;
    rule491;rule492;rule493;rule494;rule495;rule496;rule497;rule498;rule499;rule500;
    rule501;rule502;rule503;rule504;rule505;rule506;rule507;rule508;rule509;rule510;
    rule511;rule512;rule513;rule514;rule515;rule516;rule517;rule518;rule519;rule520;
    rule521;rule522;rule523;rule524;rule525;rule526;rule527;rule528;rule529;rule530;
    rule531;rule532;rule533;rule534;rule535;rule536;rule537;rule538;rule539;rule540;
    rule541;rule542;rule543;rule544;rule545;rule546;rule547;rule548;rule549;rule550;
    rule551;rule552;rule553;rule554;rule555;rule556;rule557;rule558;rule559;rule560;
    rule561;rule562;rule563;rule564;rule565;rule566;rule567;rule568;rule569;rule570;
    rule571;rule572;rule573;rule574;rule575;rule576;rule577;rule578;rule579;rule580;
    rule581;rule582;rule583;rule584;rule585;rule586;rule587;rule588;rule589;rule590;
    rule591;rule592;rule593;rule594;rule595;rule596;rule597;rule598;rule599;rule600;
    rule601;rule602;rule603;rule604;rule605;rule606;rule607;rule608;rule609;rule610;
    rule611;rule612;rule613;rule614;rule615;rule616;rule617;rule618;rule619;rule620;
    rule621;rule622;rule623;rule624;rule625];





% Add the rules to the fis

brule1 = [1 1 1 1 1 1];

brule2= [2 1 1 1 1 1];
brule3= [1 2 1 1 1 1];
brule4= [1 1 2 1 1 1];

brule5= [2 1 2 2 1 1];
brule6= [1 2 2 2 1 1];
brule7= [2 2 1 2 1 1];

brule8= [3 1 1 2 1 1];
brule9= [1 3 1 2 1 1];
brule10= [1 1 3 2 1 1];

brule11= [3 1 3 3 1 1];
brule12= [1 3 3 3 1 1];
brule13= [3 3 1 3 1 1];

brule14= [4 1 1 2 1 1];
brule15= [1 4 1 2 1 1];
brule16= [1 1 4 2 1 1];

brule17= [4 4 1 4 1 1];
brule18= [1 4 4 4 1 1];
brule19= [4 1 4 4 1 1];

brule20= [5 1 1 3 1 1];
brule21= [1 5 1 3 1 1];
brule22= [1 1 5 3 1 1];

brule23= [5 1 5 4 1 1];
brule24= [1 5 5 4 1 1];
brule25= [5 5 1 4 1 1];

brule26= [2 2 2 2 1 1];

brule27= [3 2 2 2 1 1];
brule28= [2 3 2 2 1 1];
brule29= [2 2 3 2 1 1];

brule30= [3 2 3 3 1 1];
brule31= [3 3 2 3 1 1];
brule32= [2 3 3 3 1 1];

brule33= [4 2 2 3 1 1];
brule34= [2 4 2 3 1 1];
brule35= [2 2 4 3 1 1];

brule36= [4 2 4 4 1 1];
brule37= [4 4 2 4 1 1];
brule38= [2 4 2 4 1 1];

brule39= [5 2 2 3 1 1];
brule40= [2 5 2 3 1 1];
brule41= [2 2 5 3 1 1];

brule42= [5 2 5 4 1 1];
brule43= [2 5 5 4 1 1];
brule44= [5 5 2 4 1 1];

brule45= [3 3 3 3 1 1];

brule46= [4 3 3 3 1 1];
brule47= [3 4 3 3 1 1];
brule48= [3 3 4 3 1 1];

brule49= [4 3 4 4 1 1];
brule50= [4 4 3 4 1 1];
brule51= [3 4 4 4 1 1];

brule52= [5 3 3 3 1 1];
brule53= [3 5 3 3 1 1];
brule54= [3 3 5 3 1 1];

brule55= [5 3 5 5 1 1];
brule56= [5 5 3 5 1 1];
brule57= [3 5 5 5 1 1];


brule58= [4 4 4 4 1 1];

brule59= [5 4 4 4 1 1];
brule60= [4 5 4 4 1 1];
brule61= [4 4 5 4 1 1];

brule62= [5 5 4 5 1 1];
brule63= [5 4 5 5 1 1];
brule64= [4 5 5 5 1 1];

brule65= [5 5 5 5 1 1];


brule66= [1 2 3 2 1 1];
brule67= [2 1 3 2 1 1];
brule68= [1 3 2 2 1 1];
brule69= [2 3 1 2 1 1];
brule70= [3 1 2 2 1 1];
brule71= [3 2 1 2 1 1];

brule72= [2 3 4 3 1 1];
brule73= [3 2 4 3 1 1];
brule74= [2 4 3 3 1 1];
brule75= [3 4 2 3 1 1];
brule76= [4 2 3 3 1 1];
brule77= [4 3 2 3 1 1];

brule78= [3 4 5 4 1 1];
brule79= [4 3 5 4 1 1];
brule80= [3 5 4 4 1 1];
brule81= [4 5 3 4 1 1];
brule82= [5 3 4 4 1 1];
brule83= [5 4 3 4 1 1];


brule84= [1 2 4 2 1 1];
brule85= [2 1 4 2 1 1];
brule86= [1 4 2 2 1 1];
brule87= [2 4 1 2 1 1];
brule88= [4 1 2 2 1 1];
brule89= [4 2 1 2 1 1];

brule90= [1 2 5 3 1 1];
brule91= [2 1 5 3 1 1];
brule92= [1 5 2 3 1 1];
brule93= [2 5 1 3 1 1];
brule94= [5 1 2 3 1 1];
brule95= [5 2 1 3 1 1];

brule96= [2 3 5 4 1 1];
brule97= [3 2 5 4 1 1];
brule98= [2 5 3 4 1 1];
brule99= [3 5 2 4 1 1];
brule100= [5 2 3 4 1 1];
brule101= [5 3 2 4 1 1];

brule102= [1 3 5 3 1 1];
brule103= [3 1 5 3 1 1];
brule104= [1 5 3 3 1 1];
brule105= [3 5 1 3 1 1];
brule106= [5 1 3 3 1 1];
brule107= [5 3 1 3 1 1];

brule108= [1 4 5 3 1 1];
brule109= [4 1 5 3 1 1];
brule110= [1 5 4 3 1 1];
brule111= [4 5 1 3 1 1];
brule112= [5 1 4 3 1 1];
brule113= [5 4 1 3 1 1];

brule114= [2 4 5 4 1 1];
brule115= [4 2 5 4 1 1];
brule116= [2 5 4 4 1 1];
brule117= [4 5 2 4 1 1];
brule118= [5 2 4 4 1 1];
brule119= [5 4 2 4 1 1];

brule120= [1 3 4 3 1 1];
brule121= [1 4 3 3 1 1];
brule122= [4 1 3 3 1 1];
brule123= [3 1 4 3 1 1];
brule124= [4 3 1 3 1 1];
brule125= [3 4 1 3 1 1];

Brulelist = [brule1;brule2;brule3;brule4;brule5;brule6;brule7;brule8;brule9;brule10;
    brule11;brule12;brule13;brule14;brule15;brule16;brule17;brule18;brule19;brule20;
    brule21;brule22;brule23;brule24;brule25;brule26;brule27;brule28;brule29;brule30;
    brule31;brule32;brule33;brule34;brule35;brule36;brule37;brule38;brule39;brule40;
    brule41;brule42;brule43;brule44;brule45;brule46;brule47;brule48;brule49;brule50;
    brule51;brule52;brule53;brule54;brule55;brule56;brule57;brule58;brule59;brule60;
    brule61;brule62;brule63;brule64;brule65;brule66;brule67;brule68;brule69;brule70;
    brule71;brule72;brule73;brule74;brule75;brule76;brule77;brule78;brule79;brule80;
    brule81;brule82;brule83;brule84;brule85;brule86;brule87;brule88;brule89;brule90;
    brule91;brule92;brule93;brule94;brule95;brule96;brule97;brule98;brule99;brule100;
    brule101;brule102;brule103;brule104;brule105;brule106;brule107;brule108;brule109;brule110;
    brule111;brule112;brule113;brule114;brule115;brule116;brule117;brule118;brule119;brule120;
    brule121;brule122;brule123;brule124;brule125];
crule1=[1 1 3 1 1];
crule2=[2 1 3 1 1];
crule3=[3 1 4 1 1];
crule4=[4 1 5 1 1];
crule5=[5 1 5 1 1];
crule6=[1 2 2 1 1];
crule7=[1 3 2 1 1];
crule8=[1 4 1 1 1];
crule9=[1 5 1 1 1];

crule10=[2 2 3 1 1];

crule11=[3 2 3 1 1];
crule12=[4 2 4 1 1];
crule13=[5 2 5 1 1];

crule14=[2 3 3 1 1];
crule15=[2 4 2 1 1];
crule16=[2 5 1 1 1];

crule17=[3 3 3 1 1];

crule18=[3 4 3 1 1];
crule19=[4 3 3 1 1];
crule20=[5 3 4 1 1];
crule21=[3 5 2 1 1];

crule22=[4 4 3 1 1];

crule23=[4 5 3 1 1];
crule24=[5 4 3 1 1];

crule25=[5 5 3 1 1];

Crulelist = [crule1;crule2;crule3;crule4;crule5;crule6;crule7;crule8;crule9;crule10;
    crule11;crule12;crule13;crule14;crule15;crule16;crule17;crule18;crule19;crule20;
    crule21;crule22;crule23;crule24;crule25];
a = addrule(a, AruleList);
b = addrule(b, Brulelist);
c = addrule(c, Crulelist);

climbersSkilldata=('climbersSkill.xlsx');
climbersData=xlsread(climbersSkilldata);
for i=1:size(climbersData,1)
        output = evalfis([climbersData(i, 1), climbersData(i, 2), climbersData(i, 3),climbersData(i, 4) ], a);
        fprintf('%d) In(1): %.2f, In(2) %.2f, In(3) %.2f , In(4) %.2f=> Out: %.2f \n\n',i,climbersData(i, 1),climbersData(i, 2),climbersData(i, 3),climbersData(i,4),output);  
        xlswrite('climbersSkill.xlsx', output, 1, sprintf('F%d',i+1));
        xlswrite("successOfClimber.xlsx",output,1,sprintf('A%d',i+1));

end
wallDifficultydata=('wallDifficulty.xlsx');
walldata=xlsread(wallDifficultydata);
for i=1:size(walldata,1)
    output = evalfis([walldata(i, 1), walldata(i, 2), walldata(i, 3) ], b);
    fprintf('%d) In(1): %.2e, In(2) %.2e, In(3) %.2e => Out: %.2e \n\n',i,walldata(i, 1),walldata(i, 2),walldata(i, 3),output);  
    xlswrite('wallDifficulty.xlsx', output, 1, sprintf('E%d',i+1));
    xlswrite("successOfClimber.xlsx",output,1,sprintf('B%d',i+1));
end

climberSuccessdata=('successOfClimber.xlsx');
Successdata=xlsread(climberSuccessdata);

for i=1:size(walldata,1)
    output = evalfis([Successdata(i, 1), Successdata(i, 2) ], c);
    fprintf('%d) In(1): %.2e, In(2) %.2e, In(3) %.2e => Out: %.2e \n\n',i,Successdata(i, 1),Successdata(i, 2),output);
    xlswrite('successOfClimber.xlsx', output, 1, sprintf('E%d',i+1));
end
showrule(a)
showrule(b)
showrule(c)